"use strict";
exports.id = 2548;
exports.ids = [2548];
exports.modules = {

/***/ 9813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);


const FormValue = (props)=>{
    const { title , value  } = props;
    const mb = 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                order: 4,
                weight: 500,
                mb: mb,
                size: "sm",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                size: "xs",
                children: value
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormValue);


/***/ }),

/***/ 2548:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ RenderInitialAndOtherFields),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3246);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mantine_datatable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _InvoiceFooter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2417);
/* harmony import */ var _InvoiceHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8869);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(213);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8108);
/* harmony import */ var _initial_fields_FormValue__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9813);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__]);
([_config_config__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const RenderInitialAndOtherFields = ({ fields  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Grid, {
        children: fields.map((field, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Grid.Col, {
                span: field.grid_size,
                md: field.grid_size,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_initial_fields_FormValue__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                    title: field.label,
                    value: field.value
                })
            }, `intial_${i}`))
    });
};
const RenderForm = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(({ form , userId , initial_fields , table_columns , form_title , children , extra_info_before_table , hideTotal  }, ref)=>{
    const [can_update_batch, setCanUpdateBatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { user , user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_8__/* .useAppContext */ .bp)();
    const updateForm = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
        initialValues: {
            checked_by: {
                user: "",
                signature: "",
                date: ""
            }
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const user_ = JSON.parse(user || "null");
        updateForm.setFieldValue("checked_by.user", user_?.full_name);
        setCanUpdateBatch(user_?.profile?.can_update_bank_batch);
    }, [
        user
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Paper, {
        ref: ref,
        px: 60,
        radius: "md",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
            spacing: 10,
            pt: "md",
            children: [
                form.country?.toLowerCase() === "kenya" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    mx: "auto",
                    src: _config_constants__WEBPACK_IMPORTED_MODULE_9__/* .WEBSITE_LOGO */ .S0,
                    width: 250,
                    alt: "E4I Invoice"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    mx: "auto",
                    src: _config_constants__WEBPACK_IMPORTED_MODULE_9__/* .FOUNDATION_LOGO */ .nA,
                    width: 250,
                    alt: "E4I Invoice"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InvoiceHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    invoice_number: form?.invoice_number,
                    batch_number: form?.bank_batch_no,
                    title: `${form_title}  (${form.currency?.toUpperCase()})`
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RenderInitialAndOtherFields, {
                    fields: initial_fields
                }),
                extra_info_before_table,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Paper, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        spacing: 10,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mantine_datatable__WEBPACK_IMPORTED_MODULE_3__.DataTable, {
                                horizontalSpacing: "xs",
                                verticalSpacing: 6,
                                minHeight: 100,
                                records: form?.items,
                                columns: table_columns
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                sx: {
                                    display: hideTotal ? "none" : "block"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Group, {
                                    position: "right",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Title, {
                                            order: 3,
                                            weight: 600,
                                            size: "xs",
                                            children: "Total"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Title, {
                                            order: 3,
                                            weight: 600,
                                            size: "xs",
                                            children: `${form.currency?.toUpperCase()} ${(0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(form?.total)}`
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                }),
                children,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InvoiceFooter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            ]
        })
    });
});
RenderForm.displayName = "RenderForm";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RenderForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;