"use strict";
exports.id = 1415;
exports.ids = [1415];
exports.modules = {

/***/ 9813:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);


const FormValue = (props)=>{
    const { title , value  } = props;
    const mb = 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                order: 4,
                weight: 500,
                mb: mb,
                size: "sm",
                children: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                size: "xs",
                children: value
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FormValue);


/***/ }),

/***/ 1415:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ InvoiceInitialFieldsCashAdvanceNoInputs),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_dates__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8277);
/* harmony import */ var _mantine_dates__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_dates__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8108);
/* harmony import */ var _FormValue__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9813);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_4__]);
_config_config__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const addDays = (date, days)=>{
    if (date) {
        const newDate = new Date(date.getTime());
        newDate.setDate(date.getDate() + days);
        return newDate;
    }
    return "";
};
const InvoiceInitialFieldsCashAdvance = ({ form , projects  })=>{
    const updateLiquadationDate = (value)=>{
        const liquadation_date = addDays(value, 7);
        form.setFieldValue("expected_liquidation_date", liquadation_date);
        form.setFieldValue("activity_end_date", value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Select, {
                    label: "Country",
                    ...form.getInputProps("country"),
                    data: _config_constants__WEBPACK_IMPORTED_MODULE_5__/* .COUNTRIES.map */ .od.map((e)=>({
                            label: e.country,
                            value: e.country
                        }))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 2,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Select, {
                    label: "Currency",
                    ...form.getInputProps("currency"),
                    data: _config_constants__WEBPACK_IMPORTED_MODULE_5__/* .CURRENCIES.map */ .Mf.map((cur)=>({
                            label: cur.toUpperCase(),
                            value: cur
                        }))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 5,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.TextInput, {
                    label: "Payee",
                    ...form.getInputProps("name"),
                    placeholder: "Enter Name"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_dates__WEBPACK_IMPORTED_MODULE_2__.DateInput, {
                    label: "Requisition Date",
                    ...form.getInputProps("date"),
                    minDate: new Date(),
                    placeholder: "Select Date"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.TextInput, {
                    label: "Code (will be prefilled)",
                    ...form.getInputProps("code"),
                    placeholder: "Enter Code",
                    disabled: true
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Select, {
                    label: "Project",
                    ...form.getInputProps("project"),
                    placeholder: "Project",
                    searchable: true,
                    clearable: true,
                    data: projects?.map((project)=>({
                            value: project?.id?.toString(),
                            label: project?.name
                        })) || []
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_dates__WEBPACK_IMPORTED_MODULE_2__.DateInput, {
                    label: "Activity/Mission End Date",
                    //  {...form.getInputProps('activity_end_date')}
                    value: form.values.activity_end_date,
                    onChange: (date_value)=>updateLiquadationDate(date_value),
                    minDate: new Date(),
                    placeholder: "Select Date"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_dates__WEBPACK_IMPORTED_MODULE_2__.DateInput, {
                    disabled: true,
                    label: "Expected Liquidation Date",
                    ...form.getInputProps("expected_liquidation_date"),
                    minDate: new Date(),
                    placeholder: "Select Date"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 12,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Textarea, {
                    label: "Purpose",
                    autosize: true,
                    minRows: 2,
                    ...form.getInputProps("purpose"),
                    placeholder: "Give more information about the request"
                })
            })
        ]
    });
};
const InvoiceInitialFieldsCashAdvanceNoInputs = ({ form  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Payee",
                    value: form?.name
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Requisition Date",
                    value: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .toDate */ .ZU)(form?.date)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Code",
                    value: form?.project?.code
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Project",
                    value: form?.project?.name
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Activity/Mission End Date",
                    value: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .toDate */ .ZU)(form?.activity_end_date)
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 4,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Expected Liquadation Date",
                    value: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .toDate */ .ZU)((0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .toDate */ .ZU)(form?.expected_liquidation_date))
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                md: 12,
                mb: 0,
                p: 0,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormValue__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    title: "Purpose",
                    value: form?.purpose
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InvoiceInitialFieldsCashAdvance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;