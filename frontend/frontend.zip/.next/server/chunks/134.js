"use strict";
exports.id = 134;
exports.ids = [134];
exports.modules = {

/***/ 4385:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3992);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_5__]);
_config_config__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const SidebarLink = ({ label , href , icon , children , click  })=>{
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const match = ()=>{
        const path = router.asPath;
        return (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .matchTest */ .kv)(path, href);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            children && children.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
                label: label,
                icon: icon,
                active: match(),
                style: {
                    borderRadius: theme.radius.md
                },
                children: children?.map((child, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarLink, {
                        ...child
                    }, `sidebar_child_${label}_${i}`))
            }) : null,
            !children ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
                component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
                label: label,
                href: href,
                icon: icon,
                active: match(),
                style: {
                    borderRadius: theme.radius.md
                },
                onClick: click
            }) : null
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarLink);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7307:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AdminWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6116);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mantine_hooks__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8392);
/* harmony import */ var _components_ColorSchemeToggle_ColorSchemeToggle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(222);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8108);
/* harmony import */ var _components_navigations_SidebarLink__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4385);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(213);
/* harmony import */ var _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_styles_publicStyles__WEBPACK_IMPORTED_MODULE_3__, _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_5__, _components_navigations_SidebarLink__WEBPACK_IMPORTED_MODULE_8__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_10__, _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_11__]);
([_styles_publicStyles__WEBPACK_IMPORTED_MODULE_3__, _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_5__, _components_navigations_SidebarLink__WEBPACK_IMPORTED_MODULE_8__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_10__, _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const sidebarLinkGroups = [
    {
        id: "application",
        label: "Application",
        links: [
            {
                label: "App Home",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconHome2, {
                    stroke: 1.5
                }),
                href: "/"
            },
            {
                label: "Dashboard",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconDashboard, {
                    stroke: 1.5
                }),
                href: "/admin"
            }
        ]
    },
    {
        id: "users",
        label: "Users",
        links: [
            {
                label: "All Users",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconUsers, {
                    stroke: 1.5
                }),
                href: "/admin/users"
            }
        ]
    },
    {
        id: "projects",
        label: "Projects",
        links: [
            {
                label: "All Projects",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconUsers, {
                    stroke: 1.5
                }),
                href: "/admin/projects"
            }
        ]
    }
];
function AdminWrapper({ children  }) {
    const { logout , login_status  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_10__/* .useAppContext */ .bp)();
    const [opened, setOpened] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const closeDrawer = ()=>setOpened((o)=>!o);
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_2__.useMantineTheme)();
    const { classes  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    const matches = (0,_mantine_hooks__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)("(max-width: 992px)");
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.AppShell, {
        styles: (theme)=>({
                main: {
                    backgroundColor: theme.colorScheme === "dark" ? theme.colors.dark[7] : theme.colors.gray[0],
                    overflow: "hidden",
                    transition: "color background-color 1s cubic-bezier(0.42, 0, 1, 1)"
                }
            }),
        navbarOffsetBreakpoint: "sm",
        asideOffsetBreakpoint: "sm",
        navbar: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Navbar, {
            withBorder: false,
            p: "md",
            hiddenBreakpoint: "sm",
            hidden: !opened,
            width: {
                sm: 200,
                lg: 250
            },
            style: {
                backgroundColor: theme.colorScheme === "dark" ? _config_constants__WEBPACK_IMPORTED_MODULE_7__/* .BLUE_DARK_COLOR */ .em : _config_constants__WEBPACK_IMPORTED_MODULE_7__/* .BLUE_BG_COLOR */ .sG
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Navbar.Section, {
                    grow: true,
                    component: _mantine_core__WEBPACK_IMPORTED_MODULE_2__.ScrollArea,
                    scrollbarSize: 4,
                    mx: "-xs",
                    px: "xs",
                    children: sidebarLinkGroups.map((group, i)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Box, {
                            mb: 10,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    mb: 6,
                                    children: group.label
                                }),
                                group.links.map((link, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navigations_SidebarLink__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                        ...link,
                                        click: closeDrawer
                                    }, `${index}_nav`))
                            ]
                        }, `group_${group.id}`))
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Navbar.Section, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        style: {
                            height: "130px"
                        },
                        justify: "flex-end",
                        spacing: 0,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navigations_SidebarLink__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconSettings, {
                                    stroke: 1.5
                                }),
                                label: "Settings",
                                href: "/",
                                click: closeDrawer
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.NavLink, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconLogout, {
                                    stroke: 1.5
                                }),
                                label: "Logout",
                                onClick: ()=>{
                                    closeDrawer();
                                    logout();
                                },
                                style: {
                                    borderRadius: theme.radius.md
                                }
                            })
                        ]
                    })
                })
            ]
        }),
        header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Header, {
            withBorder: false,
            zIndex: 150,
            height: {
                base: 50,
                md: 60
            },
            px: "md",
            py: "xs",
            sx: (theme)=>({
                    backgroundColor: theme.colorScheme === "dark" ? _config_constants__WEBPACK_IMPORTED_MODULE_7__/* .BLUE_DARK_COLOR */ .em : _config_constants__WEBPACK_IMPORTED_MODULE_7__/* .BLUE_BG_COLOR */ .sG
                }),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    height: "100%"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "h-100",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.MediaQuery, {
                                largerThan: "sm",
                                styles: {
                                    display: "none"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Burger, {
                                    opened: opened,
                                    onClick: ()=>setOpened((o)=>!o),
                                    size: "sm",
                                    color: theme.colors.gray[6],
                                    mr: "xl"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: _config_constants__WEBPACK_IMPORTED_MODULE_7__/* .WEBSITE_LOGO */ .S0,
                                className: classes.image
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Group, {
                        spacing: "sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ColorSchemeToggle_ColorSchemeToggle__WEBPACK_IMPORTED_MODULE_6__/* .ColorSchemeToggle */ .e, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        }),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                minHeight: "90vh"
            },
            children: children
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8108);
// middleware/requireAuth.js

const requireAdminMiddleware = (req, res, next)=>{
    const cookies = req?.cookies;
    const user = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_0__/* .LOCAL_STORAGE_KEYS.user */ .dA.user];
    const user_ = JSON.parse(user ?? "null");
    if (!user_?.is_superuser) {
        res.writeHead(302, {
            location: "/?admin_only=true"
        });
        res.end();
        return;
    }
    // User is authenticated, allow them to access the page
    next();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (requireAdminMiddleware);


/***/ })

};
;