"use strict";
exports.id = 5329;
exports.ids = [5329];
exports.modules = {

/***/ 5329:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "U": () => (/* binding */ makeRequestOne)
/* harmony export */ });
/* unused harmony exports getTheme, getPrimaryColor, formatCurrency, checkIfEndwithSlash, removeLastSlash, matchTest, makeRequest, modalOptions, createImageURl, toDate, limitChars, alertModalOptions, formatDateToYYYYMMDD, convertJSONToFormData, makeNotification */
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9294);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const getTheme = (theme)=>{
    return theme?.colorScheme === "dark";
};
const getPrimaryColor = (theme)=>{
    return theme?.colors?.orange[6];
};
const formatCurrency = (price)=>{
    if (price) {
        return Number(price).toLocaleString("en-US", {
            minimumFractionDigits: 2
        });
    }
    return "";
};
const checkIfEndwithSlash = (st)=>{
    const len = st.length;
    const end = st.substring(len - 1, len);
    const regex = new RegExp(/\//);
    return regex.test(end);
};
const removeLastSlash = (st)=>{
    const len = st.length;
    return st.substring(0, len - 1);
};
const matchTest = (str1, str2)=>{
    let string1 = str1;
    let string2 = str2;
    const str1endswithslash = checkIfEndwithSlash(string1);
    const str2endswithslash = checkIfEndwithSlash(string2);
    if (str1endswithslash) {
        string1 = removeLastSlash(string1);
    }
    if (str2endswithslash) {
        string2 = removeLastSlash(string2);
    }
    const testpath = `^${string1}$`;
    const regex = new RegExp(testpath, "gi");
    return regex.test(string2);
};
const makeRequest = async (url, method, extra_headers, data, params = {})=>{
    const options = {
        method: method,
        url: url,
        headers: {
            // 'Content-Type': 'application/json',
            ...extra_headers
        },
        data: data,
        params: params
    };
    return await axios.request(options).then((response)=>{
        return {
            "success": response.data
        };
    }).catch(function(error) {
        return {
            "error": error
        };
    });
};
const makeRequestOne = async ({ url , method , extra_headers , data , params , useNext  })=>{
    let BASE_URL = _constants__WEBPACK_IMPORTED_MODULE_1__/* .DEFAULT_API_ROOT */ .o9;
    if (useNext) {
        BASE_URL = `${_constants__WEBPACK_IMPORTED_MODULE_1__/* .DEFAULT_APP_URL */ .jl}/api`;
    }
    const options = {
        method: method,
        url: `${BASE_URL}${url}/`,
        headers: {
            ...extra_headers
        },
        data: data,
        params: params
    };
    return axios__WEBPACK_IMPORTED_MODULE_0__["default"].request(options);
};
const modalOptions = (theme)=>{
    return {
        radius: theme?.radius?.lg,
        sx: {
            ".mantine-Modal-modal": {
                background: getTheme(theme) ? BLUE_DARK_COLOR : theme.colors.gray[0]
            }
        },
        overlayOpacity: 0.7,
        overlayBlur: 0.7
    };
};
const createImageURl = (file)=>{
    return URL.createObjectURL(file);
};
const toDate = (datestring, full = false)=>{
    if (full) {
        return `${new Date(datestring).toDateString()} (${new Date(datestring).toLocaleTimeString()})`;
    }
    return new Date(datestring).toDateString();
};
const limitChars = (word, limit)=>{
    if (word?.length <= limit) {
        return word;
    }
    return word?.substring(0, limit) + "...";
};
const alertModalOptions = {
    radius: "lg",
    size: "md",
    centered: true,
    padding: 0,
    styles: {
        header: {
            display: "None"
        }
    }
};
function formatDateToYYYYMMDD(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
}
function convertJSONToFormData(jsonData) {
    const formData = new FormData();
    function appendFormData(data, keyPrefix = "") {
        if (typeof data === "object" && data !== null) {
            for(const key in data){
                if (Object.hasOwnProperty.call(data, key)) {
                    const value = data[key];
                    const fullKey = keyPrefix ? `${keyPrefix}[${key}]` : key;
                    if (typeof value === "object" && value !== null && !Array.isArray(value)) {
                        if (fullKey === "requested_by[signature]") {
                            formData.append(fullKey, value);
                        }
                        appendFormData(value, fullKey);
                    } else if (value instanceof File) {
                        formData.append(fullKey, value);
                    } else {
                        formData.append(fullKey, value);
                    }
                }
            }
        }
    }
    appendFormData(jsonData);
    return formData;
}
function makeNotification(notification, token) {
    makeRequestOne({
        url: URLS.NOTIFICATIONS,
        method: "POST",
        data: notification,
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        useNext: true
    }).then(()=>{}).catch(()=>{});
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9294:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "jl": () => (/* binding */ DEFAULT_APP_URL),
/* harmony export */   "ns": () => (/* binding */ URLS),
/* harmony export */   "o9": () => (/* binding */ DEFAULT_API_ROOT)
/* harmony export */ });
/* unused harmony exports APP_NAME, SEPARATOR, THEME_COOKIE_NAME, APP_KEY, BLUE_DARK_COLOR, BLUE_BG_COLOR, PRIMARY_SHADE, containerSize, EMOJIS, INVOICE_LEVELS, DEFAULT_MEDIA_PAGE_SIZE, LINK_WEIGHT, WEBSITE_LOGO, FOUNDATION_LOGO, INVOICE_IMAGE, COUNTRIES, CURRENCIES, LOCAL_STORAGE_KEYS */
// export const DEFAULT_API_ROOT = 'http://localhost:8000'
// export const DEFAULT_APP_URL = "http://localhost:3000"
const DEFAULT_API_ROOT = "https://api.procurement.e4impactkenya.org";
const DEFAULT_APP_URL = "https://procurement.e4impactkenya.org";
const APP_NAME = "E4IMPACT";
const SEPARATOR = "|";
const THEME_COOKIE_NAME = "e4i-template-theme";
const APP_KEY = "E4IMPACT";
// App Colors
// export const BLUE_DARK_COLOR = 'rgb(36, 42, 73)'
// export const BLUE_BG_COLOR = "#d3d6e9"
const BLUE_DARK_COLOR = "#131419";
const BLUE_BG_COLOR = "#fff";
const PRIMARY_SHADE = (/* unused pure expression or super */ null && ([
    "#23A455",
    "#23A455",
    "#23A455",
    "#23A455",
    "#23A455",
    "#23A455"
]));
const containerSize = "lg";
const URLS = {
    // AUTH
    REGISTER: `/account`,
    LOGIN: `/auth/login`,
    LOGOUT: `/auth/logout`,
    REQUEST_PASSWORD_RESET: `/auth/password-reset`,
    PASSWORD_RESET_CONFIRM: `/auth/password-reset/confirm`,
    PASSWORD_RESET_VALIDATE_TOKEN: `/auth/password-reset/validate-token`,
    CHECK_LOGIN_STATUS: "/auth/check-login-status",
    // USERS
    USERS: `/account`,
    // Accounting
    PROJECTS: `/accounting/projects`,
    PROJECT_MANAGERS: `/accounting/project-managers`,
    BUDGET_LINES: `/accounting/budget-lines`,
    FORM_USERS: `/accounting/form-users`,
    AMOUNT_RECEIVED: `/accounting/amount-received`,
    CASH_ADVANCE_FORMS: `/accounting/cash-advance-forms`,
    EXPENSE_CLAIM_FORMS: `/accounting/expense-claim-forms`,
    PURCHASE_REQUISITION_FORMS: `/accounting/purchase-requisition-forms`,
    REQUEST_FOR_QUOTATION_FORMS: `/accounting/request-for-quotation-forms`,
    LOCAL_PURCHASE_ORDER_FORMS: `/accounting/local-purchase-order-forms`,
    OVER_EXPENDITURE_FORMS: `/accounting/over-expenditure-forms`,
    UNDER_EXPENDITURE_FORMS: `/accounting/under-expenditure-forms`,
    // Notifications
    NOTIFICATIONS: `/accounting/notifications`
};
const EMOJIS = {
    "100": "\uD83D\uDCAF",
    "1234": "\uD83D\uDD22",
    "grinning": "\uD83D\uDE00",
    "grimacing": "\uD83D\uDE2C",
    "grin": "\uD83D\uDE01",
    "joy": "\uD83D\uDE02",
    "rofl": "\uD83E\uDD23",
    "partying": "\uD83E\uDD73",
    "partypopper": "\uD83C\uDF89",
    "smiley": "\uD83D\uDE03",
    "smile": "\uD83D\uDE04",
    "sweat_smile": "\uD83D\uDE05",
    "laughing": "\uD83D\uDE06",
    "innocent": "\uD83D\uDE07",
    "wink": "\uD83D\uDE09",
    "blush": "\uD83D\uDE0A",
    "slightly_smiling_face": "\uD83D\uDE42",
    "upside_down_face": "\uD83D\uDE43",
    "relaxed": "☺️",
    "yum": "\uD83D\uDE0B",
    "relieved": "\uD83D\uDE0C",
    "heart_eyes": "\uD83D\uDE0D",
    "kissing_heart": "\uD83D\uDE18",
    "kissing": "\uD83D\uDE17",
    "kissing_smiling_eyes": "\uD83D\uDE19",
    "kissing_closed_eyes": "\uD83D\uDE1A",
    "stuck_out_tongue_winking_eye": "\uD83D\uDE1C",
    "zany_face": "\uD83E\uDD2A",
    "raised_eyebrow": "\uD83E\uDD28",
    "monocle_face": "\uD83E\uDDD0",
    "stuck_out_tongue_closed_eyes": "\uD83D\uDE1D"
};
const INVOICE_LEVELS = {
    LEVEL_1: 1,
    LEVEL_2: 2,
    LEVEL_3: 3,
    LEVEL_4: 4
};
const DEFAULT_MEDIA_PAGE_SIZE = 25;
const LINK_WEIGHT = 500;
const WEBSITE_LOGO = "https://e4impactkenya.org/wp-content/uploads/2021/11/E4Impact-Kenya.jpg";
const FOUNDATION_LOGO = "https://e4impact.org/wp-content/uploads/2022/05/logo-header-retina-2022.png";
const INVOICE_IMAGE = `${DEFAULT_APP_URL}/logos/invoice-logo.png`;
const COUNTRIES = [
    {
        country: "Kenya",
        code: "ke"
    },
    {
        country: "Italy",
        code: "it"
    }
];
const CURRENCIES = (/* unused pure expression or super */ null && ([
    "usd",
    "kes",
    "euro"
]));
const LOCAL_STORAGE_KEYS = {
    user: `${APP_KEY}_user`,
    user_id: `${APP_KEY}_user_id`,
    token: `${APP_KEY}_token`,
    login_status: `${APP_KEY}_login_status`
};


/***/ })

};
;