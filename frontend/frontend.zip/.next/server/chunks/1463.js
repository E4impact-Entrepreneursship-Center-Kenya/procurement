"use strict";
exports.id = 1463;
exports.ids = [1463];
exports.modules = {

/***/ 4257:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_5__]);
_config_config__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const HeaderLink = ({ label , href , icon  })=>{
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const match = ()=>{
        const path = router.asPath;
        return (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .matchTest */ .kv)(path, href);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Anchor, {
        href: href,
        component: (next_link__WEBPACK_IMPORTED_MODULE_2___default()),
        mr: "xl",
        color: match() ? _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2] : (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .getTheme */ .gh)(theme) ? theme.white : theme.colors.dark[6],
        size: "kmd",
        underline: false,
        weight: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .LINK_WEIGHT */ .OP,
        children: label
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderLink);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1463:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export LogoutLink */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_hooks__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ColorSchemeToggle_ColorSchemeToggle__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(222);
/* harmony import */ var _components_navigations_HeaderLink__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4257);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6116);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(213);
/* harmony import */ var _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8392);
/* harmony import */ var _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2752);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_navigations_HeaderLink__WEBPACK_IMPORTED_MODULE_5__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__, _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_12__, _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_13__]);
([_components_navigations_HeaderLink__WEBPACK_IMPORTED_MODULE_5__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__, _components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_12__, _components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const CustomDrawerLink = (props)=>{
    const { label , href , icon , children , loginRequired , click  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children && children.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
            label: label,
            icon: icon,
            children: children?.map((child, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomDrawerLink, {
                    ...child
                }, `drawer_child_${label}_${i}`))
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Anchor, {
            component: (next_link__WEBPACK_IMPORTED_MODULE_8___default()),
            href: href,
            passHref: true,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
                icon: icon,
                label: label,
                onClick: click
            })
        })
    });
};
const navlinks = [
    {
        label: "Home",
        href: "/",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconHome2, {
            stroke: 1.5,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2]
        })
    }
];
const accountLinks = [
    {
        label: "Sign Up",
        href: "/auth/signup",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconUserPlus, {
            stroke: 1.5,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2]
        }),
        loginRequired: false
    },
    {
        label: "Login",
        href: "/auth/login",
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconLogin, {
            stroke: 1.5,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2]
        }),
        loginRequired: false
    }
];
const LogoutLink = ()=>{
    const handleLogout = ()=>{
        (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_10__.showNotification)({
            title: "Account logout",
            message: "You have logged out successfully",
            color: "blue",
            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconAlertCircle, {
                stroke: 1.5
            })
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconLogout, {
            stroke: 1.5,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2]
        }),
        label: "Logout",
        onClick: handleLogout
    });
};
const HeaderAndFooterWrapper = ({ children  })=>{
    const [opened, setOpened] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const [loggedIn, setLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const closeDrawer = ()=>setOpened((o)=>!o);
    const { login_status  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_11__/* .useAppContext */ .bp)();
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineTheme)();
    const { classes  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    const matches = (0,_mantine_hooks__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)("(max-width: 992px)");
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (login_status !== null) {
            setLoggedIn(login_status);
        } else {
            setLoggedIn(false);
        }
    }, [
        login_status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.AppShell, {
        styles: (theme)=>({
                main: {
                    backgroundColor: theme.colorScheme === "dark" ? theme.colors.dark[7] : _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .BLUE_BG_COLOR */ .sG,
                    overflow: "hidden",
                    transition: "color background-color 1s cubic-bezier(0.42, 0, 1, 1)"
                }
            }),
        navbarOffsetBreakpoint: "sm",
        asideOffsetBreakpoint: "sm",
        hidden: !loggedIn,
        padding: 0,
        header: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Header, {
            withBorder: true,
            height: {
                base: 60,
                md: 70
            },
            px: "md",
            py: "xs",
            sx: (theme)=>({
                    backgroundColor: theme.colorScheme === "dark" ? _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .BLUE_DARK_COLOR */ .em : _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .BLUE_BG_COLOR */ .sG
                }),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    height: "100%"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "h-100",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.MediaQuery, {
                                largerThan: "sm",
                                styles: {
                                    display: "none"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Burger, {
                                    opened: opened,
                                    onClick: ()=>setOpened((o)=>!o),
                                    size: "sm",
                                    color: theme.colors.gray[6],
                                    mr: "xl"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .WEBSITE_LOGO */ .S0,
                                className: classes.image
                            })
                        ]
                    }),
                    matches ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: navlinks.map((link, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_navigations_HeaderLink__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                ...link
                            }, `header_link_${i}`))
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                        spacing: "sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_CustomNotifications__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ColorSchemeToggle_ColorSchemeToggle__WEBPACK_IMPORTED_MODULE_4__/* .ColorSchemeToggle */ .e, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_AccountBtn__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                        ]
                    })
                ]
            })
        }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                style: {
                    minHeight: "90vh"
                },
                children: children
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
                opened: opened,
                onClose: ()=>setOpened(false),
                title: "Menu",
                padding: "xl",
                size: "md",
                position: "bottom",
                styles: {
                    content: {
                        borderTopLeftRadius: "30px !important",
                        borderTopRightRadius: "30px !important"
                    },
                    header: {
                        boxShadow: theme.shadows.md
                    }
                },
                overlayProps: {
                    opacity: .3,
                    blur: 5
                },
                withOverlay: true,
                shadow: "lg",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        spacing: 0,
                        children: navlinks.map((linkInfo, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomDrawerLink, {
                                ...linkInfo,
                                click: closeDrawer
                            }, `drawer_link_${i}`))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NavLink, {
                        label: "Account",
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconUserCircle, {
                            stroke: 1.5,
                            color: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .PRIMARY_SHADE[2] */ .VI[2]
                        }),
                        children: loggedIn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                accountLinks.filter((e)=>e.loginRequired === true).map((linkInfo, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomDrawerLink, {
                                        ...linkInfo,
                                        click: closeDrawer
                                    }, `drawer_link_loggedin_${i}`)),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LogoutLink, {})
                            ]
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: accountLinks.filter((e)=>e.loginRequired === false).map((linkInfo, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomDrawerLink, {
                                    ...linkInfo,
                                    click: closeDrawer
                                }, `drawer_link_account_${i}`))
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Box, {
                        sx: {
                            height: "30px"
                        }
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeaderAndFooterWrapper);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;