"use strict";
exports.id = 786;
exports.ids = [786];
exports.modules = {

/***/ 2417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const InvoiceFooter = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                size: "sm",
                align: "center",
                children: [
                    "Milan Office: ALTIS Via San Vittore, Milan - Italy; Email: ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "mailto:info@4impact.org",
                        children: "info@4impact.org"
                    }),
                    "; Tel: ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "tel:+390272348383",
                        children: "+39 02 7234 8383"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                size: "sm",
                align: "center",
                children: [
                    "East African Office: Email ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "mailto:accelerator.kenya@4impact.org",
                        children: "accelerator.kenya@4impact.org"
                    }),
                    "; Tel: ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: "tel:+254712526952",
                        children: "+254 712 526 952"
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InvoiceFooter);


/***/ }),

/***/ 8869:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ invoice_InvoiceHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "@mantine/core"
var core_ = __webpack_require__(2247);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./components/invoice/InvoiceTitle.tsx



const InvoiceTitle = ({ title , invoice_number , batch_number  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Paper, {
            py: 4,
            sx: (theme)=>({
                    border: `1px solid ${theme.colors.green[6]}`
                }),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Group, {
                spacing: 10,
                position: "center",
                align: "center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                        color: "green",
                        weight: 600,
                        align: "center",
                        size: "xs",
                        children: title
                    }),
                    invoice_number ? /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                        size: "xs",
                        children: invoice_number
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(core_.TextInput, {
                        size: "xs",
                        maw: 100,
                        disabled: true,
                        placeholder: "No."
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.Box, {
                        children: "|"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                        size: "xs",
                        children: "Bank Batch No."
                    }),
                    batch_number ? /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                        size: "xs",
                        children: batch_number
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(core_.TextInput, {
                        size: "xs",
                        maw: 100,
                        disabled: true,
                        placeholder: "No."
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const invoice_InvoiceTitle = (InvoiceTitle);

;// CONCATENATED MODULE: ./components/invoice/InvoiceHeader.tsx




const InvoiceHeader = (props)=>{
    const { form , title , batch_number  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Grid, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(core_.Grid.Col, {
                span: 9,
                children: /*#__PURE__*/ jsx_runtime_.jsx(invoice_InvoiceTitle, {
                    title: title,
                    invoice_number: form?.invoice_number,
                    batch_number: batch_number
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(core_.Grid.Col, {
                span: 3,
                children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Group, {
                    position: "right",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Stack, {
                        spacing: 0,
                        align: "right",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                                size: "xs",
                                children: "E4Impact Foundation"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                                size: "xs",
                                children: "Via San Vittore, 18"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                                size: "xs",
                                children: "20133 Milano, Italy"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(core_.Text, {
                                size: "xs",
                                children: "PIV: 09311470968"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const invoice_InvoiceHeader = (InvoiceHeader);


/***/ })

};
;