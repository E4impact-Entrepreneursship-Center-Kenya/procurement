"use strict";
exports.id = 1053;
exports.ids = [1053];
exports.modules = {

/***/ 222:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ ColorSchemeToggle)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);




function ColorSchemeToggle() {
    const { colorScheme , toggleColorScheme  } = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineColorScheme)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
        position: "center",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.ActionIcon, {
            onClick: ()=>toggleColorScheme(),
            size: "xl",
            sx: (theme)=>({
                    backgroundColor: theme.colorScheme === "dark" ? theme.colors.dark[6] : theme.colors.gray[0],
                    color: theme.colorScheme === "dark" ? _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .PRIMARY_SHADE[2] */ .VI[2] : theme.colors.blue[6]
                }),
            children: colorScheme === "dark" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconSun, {
                size: 20,
                stroke: 1.5
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconMoonStars, {
                size: 20,
                stroke: 1.5
            })
        })
    });
}


/***/ }),

/***/ 8392:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(213);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3992);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6116);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_appProvider__WEBPACK_IMPORTED_MODULE_4__, _config_config__WEBPACK_IMPORTED_MODULE_6__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__]);
([_providers_appProvider__WEBPACK_IMPORTED_MODULE_4__, _config_config__WEBPACK_IMPORTED_MODULE_6__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








function AccountBtn() {
    const { user , logout , login_status  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_4__/* .useAppContext */ .bp)();
    const [loggedInUser, setloggedInUser] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(null);
    const [loggedIn, setLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { theme  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setLoggedIn(login_status);
        setloggedInUser(JSON.parse(user ? user : "{}"));
    }, [
        login_status,
        user
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu, {
        shadow: "md",
        width: 200,
        radius: "md",
        withArrow: true,
        arrowSize: 16,
        transitionProps: {
            transition: "slide-up"
        },
        zIndex: 3000,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Target, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                    size: 44,
                    radius: "md",
                    sx: {
                        background: (0,_config_config__WEBPACK_IMPORTED_MODULE_6__/* .getTheme */ .gh)(theme) ? theme.colors.dark[7] : theme.colors.gray[0],
                        cursor: "pointer",
                        textTransform: "uppercase",
                        zIndex: 3000
                    },
                    src: loggedInUser?.profile?.avatar?.image_url,
                    children: loggedInUser?.username ? loggedInUser.username[0] : "L"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Dropdown, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Label, {
                        children: loggedIn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                "Welcome back ",
                                (0,_config_config__WEBPACK_IMPORTED_MODULE_6__/* .limitChars */ .kP)(loggedInUser?.username, 16)
                            ]
                        }) : "Application"
                    }),
                    loggedIn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconSettings, {
                                    size: 14
                                }),
                                component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                href: "/account",
                                children: "Account"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconQuote, {
                                    size: 14
                                }),
                                component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                href: "/account/forms",
                                children: "My Forms"
                            }),
                            loggedInUser?.is_superuser ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Divider, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                        component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                        href: "/admin",
                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconDashboard, {
                                            size: 14
                                        }),
                                        children: "Admin"
                                    })
                                ]
                            }) : null,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Divider, {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                color: "red",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconLogout, {
                                    size: 14
                                }),
                                onClick: logout,
                                children: "Logout"
                            })
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                href: "/auth/login",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconLogin, {
                                    size: 14
                                }),
                                children: "Login"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Item, {
                                component: (next_link__WEBPACK_IMPORTED_MODULE_5___default()),
                                href: "/auth/signup",
                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_2__.IconUserPlus, {
                                    size: 14
                                }),
                                children: "Sign Up"
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AccountBtn);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2752:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3992);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(32);
/* harmony import */ var _mantine_hooks__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mantine_hooks__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5941);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(213);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var html_react_parser__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2905);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_2__, swr__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__, html_react_parser__WEBPACK_IMPORTED_MODULE_10__]);
([_config_config__WEBPACK_IMPORTED_MODULE_2__, swr__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__, html_react_parser__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const SingleNotification = ({ notification , mutate  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_7__/* .useAppContext */ .bp)();
    function markAsRead() {
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_2__/* .makeRequestOne */ .U)({
            url: `${_config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.NOTIFICATIONS */ .ns.NOTIFICATIONS}/${notification?.id}`,
            method: "PUT",
            data: {
                read: true
            },
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            params: {
                fields: "read"
            },
            useNext: true
        }).then(()=>{
            setLoading(false);
            mutate && mutate();
        }).catch(()=>{});
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
        noWrap: true,
        p: "xs",
        sx: (theme)=>({
                background: (0,_config_config__WEBPACK_IMPORTED_MODULE_2__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[1],
                borderRadius: theme.radius.md,
                position: "relative"
            }),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.LoadingOverlay, {
                visible: loading
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                style: {
                    fontSize: "22px",
                    textTransform: "capitalize"
                },
                children: notification?.sender?.username[0]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                spacing: 0,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        size: "sm",
                        weight: 600,
                        children: notification?.form
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                        position: "apart",
                        align: "center",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                size: "xs",
                                children: (0,html_react_parser__WEBPACK_IMPORTED_MODULE_10__["default"])(notification?.message)
                            }),
                            notification?.read ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                size: "xs",
                                color: "blue",
                                style: {
                                    cursor: "pointer"
                                },
                                onClick: markAsRead,
                                children: "Mark as Read"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
function CustomNotifications() {
    const { user_id  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_7__/* .useAppContext */ .bp)();
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineTheme)();
    const matches = (0,_mantine_hooks__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)("(max-width: 500px)");
    const all_notifications = (0,swr__WEBPACK_IMPORTED_MODULE_5__["default"])({
        method: "GET",
        url: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.NOTIFICATIONS */ .ns.NOTIFICATIONS,
        params: {
            receiver__id: user_id,
            // sender__id: user_id,
            limit: 20,
            ordering: "-id"
        }
    }, _config_config__WEBPACK_IMPORTED_MODULE_2__/* .makeRequestOne */ .U);
    const all_notifs = all_notifications?.data?.data?.results;
    const unread_notifications = (0,swr__WEBPACK_IMPORTED_MODULE_5__["default"])({
        method: "GET",
        url: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.NOTIFICATIONS */ .ns.NOTIFICATIONS,
        params: {
            receiver__id: user_id,
            // sender__id: user_id,
            limit: 20,
            ordering: "-id",
            read: false
        }
    }, _config_config__WEBPACK_IMPORTED_MODULE_2__/* .makeRequestOne */ .U);
    const unread_notifs = unread_notifications?.data?.data?.results;
    const read_notifications = (0,swr__WEBPACK_IMPORTED_MODULE_5__["default"])({
        method: "GET",
        url: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.NOTIFICATIONS */ .ns.NOTIFICATIONS,
        params: {
            receiver__id: user_id,
            // sender__id: user_id,
            limit: 20,
            ordering: "-id",
            read: true
        }
    }, _config_config__WEBPACK_IMPORTED_MODULE_2__/* .makeRequestOne */ .U);
    const read_notifs = read_notifications?.data?.data?.results;
    const segmentForm = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_8__.useForm)({
        initialValues: {
            tab: "all"
        }
    });
    const mutatate = ()=>{
        all_notifications?.mutate();
        unread_notifications?.mutate();
        read_notifications?.mutate();
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
        position: "center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu, {
            zIndex: 1000,
            width: matches ? 320 : 350,
            radius: "md",
            position: matches ? "bottom-start" : "bottom-end",
            shadow: "lg",
            withArrow: false,
            openDelay: 200,
            closeDelay: 400,
            styles: {
                dropdown: {
                    border: `1px solid ${theme.colors.green[6]}`
                }
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Target, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Indicator, {
                        inline: true,
                        label: unread_notifs?.length,
                        radius: "sm",
                        color: "red",
                        px: "xs",
                        size: 16,
                        position: "bottom-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Avatar, {
                            size: 44,
                            radius: "md",
                            sx: (theme)=>({
                                    background: (0,_config_config__WEBPACK_IMPORTED_MODULE_2__/* .getTheme */ .gh)(theme) ? theme.colors.dark[7] : theme.colors.gray[0],
                                    cursor: "pointer",
                                    textTransform: "uppercase"
                                }),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconBell, {})
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Menu.Dropdown, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                        spacing: "xs",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                                order: 4,
                                weight: 600,
                                color: "green",
                                size: 14,
                                children: "NOTIFICATIONS"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.SegmentedControl, {
                                ...segmentForm.getInputProps("tab"),
                                color: "green",
                                size: "sm",
                                radius: "md",
                                data: [
                                    {
                                        label: `All (${all_notifs?.length})`,
                                        value: "all"
                                    },
                                    {
                                        label: `Unread (${unread_notifs?.length})`,
                                        value: "unread"
                                    },
                                    {
                                        label: `Read (${read_notifs?.length})`,
                                        value: "read"
                                    }
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.ScrollArea, {
                                h: 300,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Tabs, {
                                    value: segmentForm.values.tab,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Tabs.Panel, {
                                            value: "all",
                                            pt: "xs",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                                spacing: 6,
                                                children: [
                                                    all_notifs?.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        align: "center",
                                                        weight: 600,
                                                        children: "No notifcations"
                                                    }) : null,
                                                    all_notifs?.map((notification, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SingleNotification, {
                                                            mutate: mutatate,
                                                            notification: notification
                                                        }, `notification_${i}`))
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Tabs.Panel, {
                                            value: "unread",
                                            pt: "xs",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                                spacing: 6,
                                                children: [
                                                    unread_notifs?.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        align: "center",
                                                        weight: 600,
                                                        children: "No notifcations"
                                                    }) : null,
                                                    unread_notifs?.map((notification, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SingleNotification, {
                                                            mutate: mutatate,
                                                            notification: notification
                                                        }, `unread_notification_${notification?.id}`))
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Tabs.Panel, {
                                            value: "read",
                                            pt: "xs",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                                                spacing: 6,
                                                children: [
                                                    read_notifs?.length === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                                                        align: "center",
                                                        weight: 600,
                                                        children: "No notifcations"
                                                    }) : null,
                                                    read_notifs?.map((notification, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SingleNotification, {
                                                            mutate: mutatate,
                                                            notification: notification
                                                        }, `read_notification_${notification?.id}`))
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomNotifications);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6116:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_1__]);
_config_config__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_mantine_core__WEBPACK_IMPORTED_MODULE_0__.createStyles)((theme)=>({
        image: {
            height: (0,_config_config__WEBPACK_IMPORTED_MODULE_1__/* .getTheme */ .gh)(theme) ? "100%" : "100%"
        },
        footerImage: {
            width: "200px"
        },
        heroImage: {
            width: "330px !important"
        },
        color: {
            color: (0,_config_config__WEBPACK_IMPORTED_MODULE_1__/* .getTheme */ .gh)(theme) ? theme.white : _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .BLUE_DARK_COLOR */ .em
        },
        title: {
            // color: theme.colorScheme === 'dark' ? theme.white : theme.black,
            fontSize: 70,
            // fontWeight: 900,
            letterSpacing: -2,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .PRIMARY_SHADE[2] */ .VI[2],
            textTransform: "uppercase",
            [theme.fn.smallerThan("md")]: {
                fontSize: 50
            }
        },
        homeTitle: {
            fontSize: 100,
            fontWeight: 700,
            letterSpacing: -2,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .PRIMARY_SHADE[2] */ .VI[2],
            textShadow: "0 0 10px #fff, 0 0 20px #fff, 0 0 30px #fff, 0 0 40px #ff9a00, 0 0 70px #ff9a00, 0 0 80px #ff9a00, 0 0 100px #ff9a00, 0 0 150px #ff9a00",
            [theme.fn.smallerThan("md")]: {
                fontSize: 40
            }
        },
        servicesTitle: {
            fontSize: 72,
            fontWeight: 600,
            letterSpacing: -2,
            lineHeight: 1,
            textTransform: "capitalize",
            color: theme.white,
            mixBlendMode: "lighten"
        },
        title2: {
            // color: theme.colorScheme === 'dark' ? theme.white : theme.black,
            color: _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .PRIMARY_SHADE[2] */ .VI[2],
            fontSize: 50,
            // fontWeight: 600,
            letterSpacing: -2,
            [theme.fn.smallerThan("md")]: {
                fontSize: 40
            }
        },
        title3: {
            // color: theme.colorScheme === 'dark' ? theme.white : theme.black,
            color: theme.white,
            fontSize: 50,
            // fontWeight: 600,
            letterSpacing: -2,
            [theme.fn.smallerThan("md")]: {
                fontSize: 40
            }
        },
        title4: {
            color: theme.white,
            fontSize: 50,
            fontWeight: 600,
            letterSpacing: -2,
            [theme.fn.smallerThan("md")]: {
                fontSize: 30
            }
        },
        planTitle: {
            color: _config_constants__WEBPACK_IMPORTED_MODULE_2__/* .PRIMARY_SHADE[2] */ .VI[2],
            fontSize: 40,
            fontWeight: 400,
            letterSpacing: -2,
            [theme.fn.smallerThan("md")]: {
                fontSize: 30
            }
        },
        text: {
            color: theme.colorScheme === "dark" ? theme.white : theme.colors.dark[5],
            lineHeight: 1.5,
            letterSpacing: 0.5,
            textAlign: "justify"
        },
        hero_icon: {
            color: theme.colorScheme === "dark" ? theme.white : theme.colors.dark[5]
        },
        tldtitle: {
            fontSize: "14px",
            fontWeight: 600,
            color: theme.colorScheme === "dark" ? theme.white : theme.colors.dark[5]
        },
        tldprice: {
            fontSize: "14px",
            fontWeight: 400,
            color: theme.colorScheme === "dark" ? theme.white : theme.colors.dark[5]
        },
        absolute1: {
            borderRadius: theme.radius.lg,
            overflow: "hidden",
            background: `conic-gradient(from 45deg at 45% 57%, rgba(228, 60, 5, 1), rgba(230, 71, 18, 0.66))`,
            ":before": {
                content: '""',
                position: "absolute",
                bottom: 0,
                left: 0,
                width: "100%",
                height: "100%",
                backgroundColor: "#e5e5f7",
                opacity: 0.1,
                backgroundImage: `linear-gradient(30deg, #444cf7 12%, transparent 12.5%, transparent 87%, #444cf7 87.5%, #444cf7), 
                        linear-gradient(150deg, #444cf7 12%, transparent 12.5%, transparent 87%, #444cf7 87.5%, #444cf7), 
                        linear-gradient(30deg, #444cf7 12%, transparent 12.5%, transparent 87%, #444cf7 87.5%, #444cf7), 
                        linear-gradient(150deg, #444cf7 12%, transparent 12.5%, transparent 87%, #444cf7 87.5%, #444cf7), 
                        linear-gradient(60deg, #444cf777 25%, transparent 25.5%, transparent 75%, #444cf777 75%, #444cf777), 
                        linear-gradient(60deg, #444cf777 25%, transparent 25.5%, transparent 75%, #444cf777 75%, #444cf777)`,
                backgroundSize: "20px 35px",
                backgroundPosition: "0 0, 0 0, 10px 18px, 10px 18px, 0 0, 10px 18px",
                zIndex: 1
            }
        },
        arrowBox: {
            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_1__/* .getTheme */ .gh)(theme) ? theme.colors.dark[7] : theme.colors.gray[2],
            padding: theme.spacing.xs,
            borderRadius: theme.radius.md,
            cursor: "pointer",
            ":hover": {
                ".icon": {
                    animation: "arrow 1s infinite"
                }
            }
        },
        heroCardAbsolute: {
            zIndex: 1,
            position: "absolute",
            // bottom: 0,
            // left: "20px",
            width: "180px",
            height: "200px",
            // transform: "rotate(-15deg)",
            borderRadius: theme.radius.md,
            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_1__/* .getTheme */ .gh)(theme) ? "rgba(0, 0, 0, 0.3)" : "rgba(255, 255, 255, 0.3)"
        }
    })));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;