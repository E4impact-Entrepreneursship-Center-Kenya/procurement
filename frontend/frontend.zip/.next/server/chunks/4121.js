"use strict";
exports.id = 4121;
exports.ids = [4121];
exports.modules = {

/***/ 4121:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Bf": () => (/* binding */ UpdateApprovalField),
/* harmony export */   "NQ": () => (/* binding */ UpdateSingleFormField)
/* harmony export */ });
/* unused harmony export ApprovalPersonNoInput */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mantine_dates__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8277);
/* harmony import */ var _mantine_dates__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mantine_dates__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(213);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__]);
([_config_config__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ApprovalPerson = ({ person , form , field_prefix , field_name , active , level  })=>{
    return /*#__PURE__*/ _jsxs(Grid, {
        style: {
            position: "relative"
        },
        py: "sm",
        columns: 3,
        children: [
            /*#__PURE__*/ _jsx(Overlay, {
                hidden: active
            }),
            /*#__PURE__*/ _jsx(Grid.Col, {
                md: 5,
                children: /*#__PURE__*/ _jsx(TextInput, {
                    label: person,
                    ...form.getInputProps(`${field_prefix}.${field_name}`),
                    placeholder: field_name === "amount" ? "Enter Amount" : "Enter Your Name"
                })
            }),
            /*#__PURE__*/ _jsx(Grid.Col, {
                md: 4,
                children: field_name === "amount" ? /*#__PURE__*/ _jsx(FileInput, {
                    disabled: !active,
                    label: "Receipt",
                    accept: "application/pdf",
                    ...form.getInputProps(`${field_prefix}.receipt`),
                    placeholder: "Upload Receipt - PDFs only"
                }) : /*#__PURE__*/ _jsx(FileInput, {
                    disabled: !active,
                    label: "Signature",
                    accept: "image/*",
                    ...form.getInputProps(`${field_prefix}.signature`),
                    placeholder: "Upload Your Signature"
                })
            }),
            /*#__PURE__*/ _jsx(Grid.Col, {
                md: 3,
                children: /*#__PURE__*/ _jsx(DateInput, {
                    disabled: !active,
                    label: "Date",
                    ...form.getInputProps(`${field_prefix}.date`),
                    minDate: new Date(),
                    placeholder: "Select Date"
                })
            })
        ]
    });
};
const UpdateApprovalField = ({ inputLabel , formID , field_prefix , field_name , active , field_update_url , formName , data , currency  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const { user , user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_8__/* .useAppContext */ .bp)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        initialValues: {
            [field_prefix]: {
                amount: "",
                user: "",
                signature: "",
                date: ""
            }
        }
    });
    function submitUpdateForm() {
        let data = form.values;
        const formData = new FormData();
        formData.append("form_id", formID);
        formData.append("form_name", formName);
        formData.append("field_name", field_prefix);
        formData.append("amount", data[field_prefix].amount);
        formData.append("receipt", data[field_prefix].receipt);
        formData.append("user", user_id);
        formData.append("signature", data[field_prefix].signature);
        formData.append("date", (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatDateToYYYYMMDD */ .bm)(data[field_prefix].date));
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .makeRequestOne */ .U)({
            url: `${field_update_url}`,
            method: "POST",
            data: formData,
            extra_headers: {
                authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data"
            }
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_6__.showNotification)({
                message: "update successful"
            });
            router.reload();
        }).catch((err)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_6__.showNotification)({
                message: err.message,
                color: "red"
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ApprovalPersonNoInput, {
            title: inputLabel,
            person: data,
            field_name: field_name,
            currency: currency
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            onSubmit: form.onSubmit((values)=>submitUpdateForm()),
            style: {
                position: "relative"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.LoadingOverlay, {
                    visible: loading
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    style: {
                        position: "relative"
                    },
                    py: "sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Overlay, {
                            hidden: active
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                            md: 3,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.TextInput, {
                                label: inputLabel,
                                ...form.getInputProps(`${field_prefix}.${field_name}`),
                                placeholder: field_name === "amount" ? "Enter Amount" : "Enter Your Name"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                            md: 4,
                            children: field_name === "amount" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.FileInput, {
                                disabled: !active,
                                label: "Receipt",
                                accept: "application/pdf",
                                ...form.getInputProps(`${field_prefix}.receipt`),
                                placeholder: "Upload Receipt - PDFs only"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.FileInput, {
                                disabled: !active,
                                label: "Signature",
                                accept: "image/*",
                                ...form.getInputProps(`${field_prefix}.signature`),
                                placeholder: "Upload Your Signature"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                            md: 3,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_dates__WEBPACK_IMPORTED_MODULE_3__.DateInput, {
                                disabled: !active,
                                label: "Date",
                                ...form.getInputProps(`${field_prefix}.date`),
                                minDate: new Date(),
                                placeholder: "Select Date"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                            md: 2,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                                className: "h-100",
                                align: "center",
                                position: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    type: "submit",
                                    children: "Update"
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
const ApprovalPersonNoInput = ({ title , person , field_name , currency  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        style: {
            position: "relative"
        },
        p: 0,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                span: 4,
                md: 5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                        order: 4,
                        weight: 500,
                        size: 14,
                        children: title
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                        size: "xs",
                        children: field_name === "amount" ? `${currency?.toUpperCase()} ${(0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(person?.amount)}` : person?.user?.full_name
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                span: 4,
                md: 4,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                    align: "center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                            order: 4,
                            weight: 500,
                            mb: "mb",
                            size: 14,
                            children: field_name === "amount" ? `Receipt` : "Signature"
                        }),
                        field_name === "amount" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Anchor, {
                                target: "_blank",
                                href: person.receipt,
                                size: "sm",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    size: "sm",
                                    radius: "md",
                                    children: "View"
                                })
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Image, {
                            src: person?.signature,
                            width: 60,
                            alt: field_name === "amount" ? `Receipt` : "Signature"
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                span: 4,
                md: 3,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                            order: 4,
                            weight: 500,
                            size: 14,
                            children: "Date"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Text, {
                            size: "xs",
                            children: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .toDate */ .ZU)(person?.date)
                        })
                    ]
                })
            })
        ]
    });
};
const UpdateSingleFormField = (props)=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { field_type , field_name , field_value , col_size , label , form_update_url , choices  } = props;
    const { token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_8__/* .useAppContext */ .bp)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_5__.useForm)({
        initialValues: {
            [field_name]: field_value
        }
    });
    function submitUpdateForm() {
        let data = form.values;
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .makeRequestOne */ .U)({
            url: form_update_url,
            method: "PUT",
            data: data,
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            useNext: false
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_6__.showNotification)({
                message: "update successful"
            });
            router.reload();
        }).catch((err)=>{
            console.log("Error: ", err);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_6__.showNotification)({
                message: err.message,
                color: "red"
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        onSubmit: form.onSubmit((values)=>submitUpdateForm()),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            py: "xs",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                    md: col_size,
                    children: [
                        field_type == "radio" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Radio.Group, {
                            label: label,
                            withAsterisk: true,
                            ...form.getInputProps(field_name, {
                                type: "checkbox"
                            }),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                                mt: "xs",
                                children: choices?.map((choice, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Radio, {
                                        ...choice
                                    }, `choice_${i}`))
                            })
                        }) : null,
                        field_type == "switch" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Switch, {
                            label: label,
                            ...form.getInputProps(field_name, {
                                type: "checkbox"
                            })
                        }) : null,
                        field_type == "number" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.NumberInput, {
                            label: label,
                            withAsterisk: true,
                            ...form.getInputProps(field_name)
                        }) : null,
                        field_type == "text" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.TextInput, {
                            label: label,
                            withAsterisk: true,
                            ...form.getInputProps(field_name)
                        }) : null
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                    md: 2,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Group, {
                        className: "h-100",
                        align: "end",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Button, {
                            size: "xs",
                            radius: "sm",
                            type: "submit",
                            children: "Update"
                        })
                    })
                })
            ]
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (ApprovalPerson)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;