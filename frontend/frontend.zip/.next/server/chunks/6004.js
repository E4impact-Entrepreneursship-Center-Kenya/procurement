"use strict";
exports.id = 6004;
exports.ids = [6004];
exports.modules = {

/***/ 6004:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "LG": () => (/* binding */ CallToActionButtonAction)
/* harmony export */ });
/* unused harmony export CallToActionButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8108);





const CallToActionButton = (props)=>{
    const { label , icon , link  } = props;
    const theme = useMantineTheme();
    return /*#__PURE__*/ _jsx(Anchor, {
        component: Link,
        href: link ?? "/",
        passHref: true,
        children: /*#__PURE__*/ _jsx(Button, {
            sx: {
                background: PRIMARY_SHADE[2],
                color: theme.white,
                height: "40px",
                minWidth: "200px",
                ":hover": {
                    background: `${PRIMARY_SHADE[2]} !important`
                }
            },
            radius: "xl",
            leftIcon: icon,
            children: label
        })
    });
};
const CallToActionButtonAction = (props)=>{
    const { label , icon , action , type , rightIcon  } = props;
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_1__.useMantineTheme)();
    const voidFunc = ()=>{};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Button, {
        sx: {
            background: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .PRIMARY_SHADE[2] */ .VI[2],
            color: theme.white,
            height: "40px",
            minWidth: "200px",
            ":hover": {
                background: `${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .PRIMARY_SHADE[2] */ .VI[2]} !important`
            }
        },
        radius: "xl",
        type: type,
        leftIcon: icon,
        onClick: action ?? voidFunc,
        rightIcon: rightIcon ? rightIcon : null,
        children: label
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CallToActionButton)));


/***/ })

};
;