"use strict";
exports.id = 5075;
exports.ids = [5075];
exports.modules = {

/***/ 7826:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8108);
// middleware/requireAuth.js

const requireAuthMiddleware = (req, res, next)=>{
    const cookies = req?.cookies;
    const loginStatus = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_0__/* .LOCAL_STORAGE_KEYS.login_status */ .dA.login_status];
    const isAuthenticated = JSON.parse(loginStatus ?? "false");
    if (isAuthenticated === false) {
        res.writeHead(302, {
            location: "/auth/login"
        });
        res.end();
        return;
    }
    // User is authenticated, allow them to access the page
    next();
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (requireAuthMiddleware);


/***/ }),

/***/ 5075:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "InvoiceCard": () => (/* binding */ InvoiceCard),
/* harmony export */   "LinkCard": () => (/* binding */ LinkCard),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7826);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_5__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const InvoiceCard = ({ title , href , icon  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
        href: href,
        style: {
            textDecoration: "none"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Card, {
            radius: "md",
            sx: (theme)=>({
                    background: (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[0],
                    border: "2px solid transparent",
                    ":hover": {
                        border: `2px solid ${theme.primaryColor}`
                    }
                }),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Image, {
                    src: icon,
                    mx: "auto",
                    width: 66,
                    alt: title
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                    order: 3,
                    weight: 400,
                    align: "center",
                    mt: "md",
                    children: title
                })
            ]
        })
    });
};
const LinkCard = ({ title , href , icon  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Anchor, {
        href: href,
        style: {
            textDecoration: "none",
            width: "100%",
            height: "100%",
            display: "block"
        },
        target: "_blank",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Card, {
            radius: "md",
            sx: (theme)=>({
                    background: (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[0],
                    border: "2px solid transparent",
                    height: "100%",
                    ":hover": {
                        border: `2px solid ${theme.primaryColor}`
                    }
                }),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Image, {
                    src: icon,
                    mx: "auto",
                    width: 66,
                    alt: title
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                    order: 3,
                    weight: 400,
                    align: "center",
                    mt: "md",
                    children: title
                })
            ]
        })
    });
};
const invoices = [
    {
        title: "Cash Advance",
        href: "/invoices/cash-advance",
        icon: "https://img.icons8.com/carbon-copy/100/40C057/cash-register.png"
    },
    {
        title: "Expense Claim Form",
        href: "/invoices/expense-claim-form",
        icon: "https://img.icons8.com/dotty/80/40C057/delete-receipt.png"
    },
    {
        title: "Purchase Requisition",
        href: "/invoices/purchase-requisition",
        icon: "https://img.icons8.com/dotty/80/40C057/shopping-cart-with-money.png"
    },
    {
        title: "Request For Quotation",
        href: "/invoices/request-for-quotation",
        icon: "https://img.icons8.com/carbon-copy/100/40C057/invoice.png"
    },
    // {
    //   title: "Payment Authorization",
    //   href: "/invoices/payment-authorization-form",
    //   icon: 'https://img.icons8.com/wired/64/40C057/card-in-use.png'
    // },
    {
        title: "Local Purchase Order",
        href: "/invoices/local-purchase-order",
        icon: "https://img.icons8.com/dotty/80/40C057/purchase-order.png"
    },
    {
        title: "Over Expenditure Form",
        href: "/invoices/over-expenditure-form",
        icon: "https://img.icons8.com/wired/64/40C057/estimate.png"
    },
    {
        title: "Under Expenditure Form",
        href: "/invoices/under-expenditure-form",
        icon: "https://img.icons8.com/external-smashingstocks-detailed-outline-smashing-stocks/66/40C057/external-accounting-accounting-smashingstocks-detailed-outline-smashing-stocks-3.png"
    }
];
function IndexPage(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Container, {
            py: 50,
            size: "lg",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                spacing: 40,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Title, {
                        align: "center",
                        children: "PROCUREMENT"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        children: [
                            invoices.map((invoice, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                                    md: 4,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(InvoiceCard, {
                                        ...invoice
                                    })
                                }, `invoice_card_${i}`)),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_1__.Grid.Col, {
                                md: 4,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(LinkCard, {
                                    title: "Procurement Policies & Procudures",
                                    href: "/docs/proc-policy.pdf",
                                    icon: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .WEBSITE_LOGO */ .S0
                                }, "e4i-prod-manuel")
                            })
                        ]
                    })
                ]
            })
        })
    });
}
const getServerSideProps = async (context)=>{
    (0,_middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
    return {
        props: {}
    };
};
IndexPage.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (IndexPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;