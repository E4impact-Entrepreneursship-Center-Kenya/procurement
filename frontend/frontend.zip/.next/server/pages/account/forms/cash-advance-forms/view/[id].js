"use strict";
(() => {
var exports = {};
exports.id = 5793;
exports.ids = [5793,5405];
exports.modules = {

/***/ 48:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(213);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8167);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__]);
([_config_config__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const UpdateBankBatchNo = (props)=>{
    const { formID  } = props;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_7__/* .useAppContext */ .bp)();
    const updateForm = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        initialValues: {
            bank_batch_no: ""
        },
        validate: {
            bank_batch_no: (value)=>value === "" ? "Bank Batch No. is required" : null
        }
    });
    function submitUpdateForm() {
        let data = updateForm.values;
        setLoading(true);
        let url = `${_config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.CASH_ADVANCE_FORMS */ .ns.CASH_ADVANCE_FORMS}/${formID}`;
        (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .makeRequestOne */ .U)({
            url: `${url}`,
            method: "PUT",
            data: data,
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            params: {
                fields: "bank_batch_no"
            }
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__.showNotification)({
                message: "Bank batch updated",
                color: "green"
            });
            router.reload();
        }).catch((err)=>{
            const errors = err?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_8__/* .displayErrors */ .hP)(updateForm, errors);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__.showNotification)({
                message: err.message,
                color: "red"
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
            onSubmit: updateForm.onSubmit((values)=>submitUpdateForm()),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.Grid, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.Grid.Col, {
                        span: 8,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.TextInput, {
                            label: "Bank Batch No.",
                            description: "Confirm before updating (Not Editable)",
                            ...updateForm.getInputProps("bank_batch_no"),
                            radius: "md",
                            placeholder: "Bank Batch No."
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.Grid.Col, {
                        span: 4,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.Group, {
                            align: "end",
                            className: "h-100",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_9__.Button, {
                                radius: "md",
                                loading: loading,
                                type: "submit",
                                children: "Update"
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UpdateBankBatchNo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 24:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3246);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(mantine_datatable__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _Approvals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6715);
/* harmony import */ var _ApprovalsSection__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5130);
/* harmony import */ var _InvoiceFooter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2417);
/* harmony import */ var _InvoiceHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8869);
/* harmony import */ var _initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1415);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(213);
/* harmony import */ var _UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6018);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _UpdateBankBatchNo__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(48);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_4__, _Approvals__WEBPACK_IMPORTED_MODULE_5__, _ApprovalsSection__WEBPACK_IMPORTED_MODULE_6__, _initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_9__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__, _UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__, _UpdateBankBatchNo__WEBPACK_IMPORTED_MODULE_14__]);
([_config_config__WEBPACK_IMPORTED_MODULE_4__, _Approvals__WEBPACK_IMPORTED_MODULE_5__, _ApprovalsSection__WEBPACK_IMPORTED_MODULE_6__, _initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_9__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_11__, _UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__, _UpdateBankBatchNo__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const RenderCashAdvanceForm = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(({ form , userId  }, ref)=>{
    const [can_update_batch, setCanUpdateBatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { user , user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_11__/* .useAppContext */ .bp)();
    const updateForm = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
        initialValues: {
            checked_by: {
                user: "",
                signature: "",
                date: ""
            }
        }
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const user_ = JSON.parse(user || "null");
        updateForm.setFieldValue("checked_by.user", user_?.full_name);
        setCanUpdateBatch(user_?.profile?.can_update_bank_batch);
    }, [
        user
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Paper, {
        ref: ref,
        px: 60,
        radius: "md",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
            spacing: 10,
            pt: "md",
            children: [
                form.country?.toLowerCase() === "kenya" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    mx: "auto",
                    src: _config_constants__WEBPACK_IMPORTED_MODULE_13__/* .WEBSITE_LOGO */ .S0,
                    width: 250,
                    alt: "E4I Invoice"
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Image, {
                    mx: "auto",
                    src: _config_constants__WEBPACK_IMPORTED_MODULE_13__/* .FOUNDATION_LOGO */ .nA,
                    width: 250,
                    alt: "E4I Invoice"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InvoiceHeader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    form: form,
                    title: `CASH ADVANCE FORM  (${form.currency?.toUpperCase()})`
                }),
                can_update_batch && !form.bank_batch_no && form.level === 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdateBankBatchNo__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    formID: form.id
                }) : null,
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_9__/* .InvoiceInitialFieldsCashAdvanceNoInputs */ .Y, {
                    form: form
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Paper, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        spacing: 10,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mantine_datatable__WEBPACK_IMPORTED_MODULE_3__.DataTable, {
                                horizontalSpacing: "xs",
                                verticalSpacing: 6,
                                minHeight: 100,
                                records: form?.items.concat(Array(4).fill(null)),
                                columns: [
                                    {
                                        accessor: "no",
                                        title: "No.",
                                        width: "60px",
                                        noWrap: true,
                                        render: (entry)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                children: entry ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                    children: entry?.no
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Box, {
                                                    style: {
                                                        height: "16px"
                                                    }
                                                })
                                            })
                                    },
                                    {
                                        title: "Description",
                                        accessor: "description",
                                        width: "230px"
                                    },
                                    {
                                        title: "Budget Line",
                                        noWrap: false,
                                        accessor: "budget_line",
                                        width: "100px"
                                    },
                                    {
                                        title: "Unit",
                                        accessor: "unit",
                                        width: "60px"
                                    },
                                    {
                                        title: "No. Unit(s)",
                                        accessor: "no_of_units",
                                        width: "80px",
                                        noWrap: true
                                    },
                                    {
                                        title: "Rate",
                                        accessor: "unit_rate",
                                        width: "80px",
                                        ellipsis: false,
                                        render: (item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(item?.unit_rate)
                                            })
                                    },
                                    {
                                        title: `Amount (${form.currency?.toUpperCase()})`,
                                        accessor: "amount",
                                        width: "100px",
                                        render: (item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(item?.amount)
                                            })
                                    }
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Group, {
                                position: "right",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Title, {
                                        order: 3,
                                        weight: 600,
                                        size: "xs",
                                        children: "Total"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Title, {
                                        order: 3,
                                        weight: 600,
                                        size: "xs",
                                        children: `${form.currency?.toUpperCase()} ${(0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .formatCurrency */ .xG)(form?.total)}`
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_ApprovalsSection__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_5__/* .ApprovalPersonNoInput */ .J, {
                            title: "Requested By",
                            person: form?.requested_by
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "Checked By",
                            nextLevel: 2,
                            field: "checked_by",
                            data: form?.checked_by,
                            formID: form?.id,
                            userId: userId,
                            checker: form?.checker,
                            requestedBy: form?.requested_by?.id,
                            max_level: undefined,
                            form_url: "",
                            field_update_url: ""
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "Approved By",
                            nextLevel: 3,
                            field: "approved_by",
                            data: form?.approved_by,
                            formID: form?.id,
                            userId: userId,
                            checker: form?.approver,
                            requestedBy: form?.requested_by?.id
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdateContingencyFields__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                            title: "Amount Received",
                            nextLevel: 4,
                            field: "amount_received",
                            data: form?.amount_received,
                            formID: form?.id,
                            userId: userId,
                            checker: form?.checker,
                            requestedBy: form?.requested_by?.user.id
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InvoiceFooter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
            ]
        })
    });
});
RenderCashAdvanceForm.displayName = "RenderCashAdvanceForm";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RenderCashAdvanceForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6018:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3992);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(213);
/* harmony import */ var _Approvals__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6715);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_config_config__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_6__, _Approvals__WEBPACK_IMPORTED_MODULE_7__]);
([_config_config__WEBPACK_IMPORTED_MODULE_5__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_6__, _Approvals__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const UpdateContingencyFields = ({ data , field , nextLevel , title , userId , checker , requestedBy , max_level , form_url , field_update_url  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { user , user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_6__/* .useAppContext */ .bp)();
    const updateForm = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        initialValues: {
            [field]: {
                amount: "",
                user: "",
                signature: "",
                date: ""
            }
        }
    });
    function submitUpdateForm() {
        let data = updateForm.values;
        const formData = new FormData();
        formData.append("amount", data[field].amount);
        formData.append("receipt", data[field].receipt);
        formData.append("user", user_id);
        formData.append("signature", data[field].signature);
        formData.append("date", (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .formatDateToYYYYMMDD */ .bm)(data[field].date));
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .makeRequestOne */ .U)({
            url: `${field_update_url}`,
            method: "POST",
            data: formData,
            extra_headers: {
                authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data"
            }
        }).then((res)=>{
            let updateData = {
                level: nextLevel,
                [field]: res?.data?.id
            };
            if (nextLevel === max_level) {
                updateData.is_complete = true;
            }
            (0,_config_config__WEBPACK_IMPORTED_MODULE_5__/* .makeRequestOne */ .U)({
                url: `${form_url}`,
                method: "PUT",
                extra_headers: {
                    authorization: `Bearer ${token}`
                },
                data: updateData
            }).then(()=>{
                (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__.showNotification)({
                    message: "update successful"
                });
                router.reload();
            }).catch(()=>{});
        }).catch((err)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_2__.showNotification)({
                message: err.message,
                color: "red"
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Box, {
            style: {
                position: "relative"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.LoadingOverlay, {
                    visible: loading
                }),
                data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_7__/* .ApprovalPersonNoInput */ .J, {
                    title: title,
                    person: data,
                    level: nextLevel
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: nextLevel === 4 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: requestedBy === userId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: updateForm.onSubmit((values)=>submitUpdateForm()),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                                        md: 10,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            person: title,
                                            form: updateForm,
                                            field_prefix: field,
                                            field_name: "amount",
                                            active: true,
                                            level: nextLevel
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                                        md: 2,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Group, {
                                            className: "h-100",
                                            align: "center",
                                            position: "center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Button, {
                                                type: "submit",
                                                children: "Update"
                                            })
                                        })
                                    })
                                ]
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            person: title,
                            form: updateForm,
                            field_prefix: field,
                            field_name: "amount",
                            active: false,
                            level: nextLevel
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: checker === userId ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: updateForm.onSubmit((values)=>submitUpdateForm()),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                                        md: 10,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                            person: title,
                                            form: updateForm,
                                            field_prefix: field,
                                            field_name: "user",
                                            active: true,
                                            level: nextLevel
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                                        md: 2,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Group, {
                                            className: "h-100",
                                            align: "center",
                                            position: "center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Button, {
                                                type: "submit",
                                                children: "Update"
                                            })
                                        })
                                    })
                                ]
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Approvals__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            person: title,
                            form: updateForm,
                            field_prefix: field,
                            field_name: "user",
                            active: false,
                            level: nextLevel
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UpdateContingencyFields);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 821:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8108);
/* harmony import */ var _middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7826);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _components_invoice_render_forms_RenderCashAdvanceForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(24);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8167);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(53);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_to_print__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _components_invoice_render_forms_RenderCashAdvanceForm__WEBPACK_IMPORTED_MODULE_7__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _components_invoice_render_forms_RenderCashAdvanceForm__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const SingleForm = ({ form , userId  })=>{
    const color = (0,_config_functions__WEBPACK_IMPORTED_MODULE_8__/* .getColor */ .Lq)(form?.level);
    const tip = (0,_config_functions__WEBPACK_IMPORTED_MODULE_8__/* .getTooltip */ .gB)(form?.level);
    const componentRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_11___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: `Cash Advance Form ${form?.invoice_number}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Container, {
                py: 40,
                size: "lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Progress, {
                            size: "xl",
                            striped: true,
                            animate: form?.level !== 4,
                            sections: [
                                {
                                    value: form?.level * 25,
                                    color: color,
                                    label: `Progress ${form?.level * 25}%`,
                                    tooltip: tip
                                }
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_render_forms_RenderCashAdvanceForm__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            form: form,
                            userId: userId,
                            ref: componentRef
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_to_print__WEBPACK_IMPORTED_MODULE_9___default()), {
                            trigger: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                    size: "lg",
                                    radius: "md",
                                    variant: "filled",
                                    mb: "md",
                                    leftIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_10__.IconPrinter, {}),
                                    children: "Print/Download"
                                }),
                            content: ()=>componentRef?.current
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    (0,_middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
    const { params  } = context;
    const cookies = context.req.cookies;
    // const userDetails_: any = cookies[LOCAL_STORAGE_KEYS.user]
    const token = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.token */ .dA.token];
    const user_id = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.user_id */ .dA.user_id];
    const formQuery = await (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .makeRequestOne */ .U)({
        url: `${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .URLS.CASH_ADVANCE_FORMS */ .ns.CASH_ADVANCE_FORMS}/${params?.id}`,
        method: "GET",
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        params: {
            fields: "id,country,currency,requested_by,full_name,checker,user,signature,date,amount,receipt,checked_by,approver,approved_by,amount_received,name,level,invoice_number,bank_batch_no,purpose,project,code,name,activity_end_date,expected_liquidation_date,items,total,is_completed"
        }
    });
    return {
        props: {
            form: formQuery?.data,
            userId: parseInt(user_id || "0")
        }
    };
};
SingleForm.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 8277:
/***/ ((module) => {

module.exports = require("@mantine/dates");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3246:
/***/ ((module) => {

module.exports = require("mantine-datatable");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 53:
/***/ ((module) => {

module.exports = require("react-to-print");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,786,3986,1415], () => (__webpack_exec__(821)));
module.exports = __webpack_exports__;

})();