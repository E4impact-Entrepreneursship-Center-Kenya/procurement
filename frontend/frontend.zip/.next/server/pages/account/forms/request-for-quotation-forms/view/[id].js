"use strict";
(() => {
var exports = {};
exports.id = 8668;
exports.ids = [8668,5405];
exports.modules = {

/***/ 9051:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8108);
/* harmony import */ var _middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7826);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8167);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53);
/* harmony import */ var react_to_print__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_to_print__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _components_invoice_render_forms_RenderForm__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2548);
/* harmony import */ var _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6715);
/* harmony import */ var _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5130);
/* harmony import */ var _components_invoice_initial_fields_RequestForQuotationFields__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6193);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _components_invoice_render_forms_RenderForm__WEBPACK_IMPORTED_MODULE_11__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_12__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_13__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _components_invoice_render_forms_RenderForm__WEBPACK_IMPORTED_MODULE_11__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_12__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const SingleForm = ({ form , userId  })=>{
    const color = (0,_config_functions__WEBPACK_IMPORTED_MODULE_7__/* .getColor */ .Lq)(form?.level);
    const tip = (0,_config_functions__WEBPACK_IMPORTED_MODULE_7__/* .getTooltip */ .gB)(form?.level);
    const componentRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_10___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: `Cash Advance Form ${form?.invoice_number}`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Container, {
                py: 40,
                size: "lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Progress, {
                            size: "xl",
                            striped: true,
                            animate: form?.level !== 4,
                            sections: [
                                {
                                    value: form?.level * 25,
                                    color: color,
                                    label: `Progress ${form?.level * 25}%`,
                                    tooltip: tip
                                }
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_invoice_render_forms_RenderForm__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            form_title: "Expense Claim Form",
                            form: form,
                            userId: userId,
                            ref: componentRef,
                            initial_fields: [
                                {
                                    label: "Vendor Name",
                                    value: form?.vendor_name,
                                    grid_size: 3
                                },
                                {
                                    label: "Address",
                                    value: form?.address,
                                    grid_size: 3
                                },
                                {
                                    label: "Phone Number",
                                    value: form?.phone_number ?? "-",
                                    grid_size: 3
                                },
                                {
                                    label: "Cash Advance Received",
                                    value: `${form?.currency?.toUpperCase()} ${(0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .formatCurrency */ .xG)(form?.cash_advance_received)}`,
                                    grid_size: 3
                                }
                            ],
                            extra_info_before_table: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_initial_fields_RequestForQuotationFields__WEBPACK_IMPORTED_MODULE_14__/* .RequestForQuoatationExtraInfo */ .z, {}),
                            table_columns: [
                                {
                                    accessor: "no",
                                    title: "No.",
                                    width: "60px",
                                    noWrap: true
                                },
                                {
                                    title: "Item Description",
                                    accessor: "description",
                                    width: "250px"
                                },
                                {
                                    title: "Unit",
                                    accessor: "unit",
                                    width: "60px"
                                },
                                {
                                    title: "Quantity",
                                    accessor: "qty",
                                    width: "80px"
                                },
                                {
                                    title: "Unit Price",
                                    accessor: "unit_price",
                                    width: "60px",
                                    ellipsis: false,
                                    render: (entry, i)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                            children: (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .formatCurrency */ .xG)(entry?.unit_price)
                                        });
                                    }
                                },
                                {
                                    title: `Total Cost (${form?.currency?.toUpperCase()})`,
                                    accessor: "amount",
                                    width: "100px",
                                    render: (entry, i)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("b", {
                                            children: (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .formatCurrency */ .xG)(entry?.amount)
                                        });
                                    }
                                }
                            ],
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_render_forms_RenderForm__WEBPACK_IMPORTED_MODULE_11__/* .RenderInitialAndOtherFields */ .P, {
                                    fields: [
                                        {
                                            label: "Payment Terms",
                                            value: form?.payment_terms ?? "",
                                            grid_size: 6
                                        },
                                        {
                                            label: "Delivery Period",
                                            value: form?.delivery_period ?? "",
                                            grid_size: 6
                                        },
                                        {
                                            label: "Price Validity Period",
                                            value: form?.price_validity_period ?? "",
                                            grid_size: 6
                                        },
                                        {
                                            label: "Warranty Period",
                                            value: form?.warrant_period ?? "",
                                            grid_size: 6
                                        }
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_12__/* .ApprovalPersonNoInput */ .J, {
                                        title: "Requested By",
                                        person: form?.requested_by
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_to_print__WEBPACK_IMPORTED_MODULE_8___default()), {
                            trigger: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Button, {
                                    size: "lg",
                                    radius: "md",
                                    variant: "filled",
                                    mb: "md",
                                    leftIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_9__.IconPrinter, {}),
                                    children: "Print/Download"
                                }),
                            content: ()=>componentRef?.current
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    try {
        (0,_middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
        const { params  } = context;
        const cookies = context.req.cookies;
        // const userDetails_: any = cookies[LOCAL_STORAGE_KEYS.user]
        const token = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.token */ .dA.token];
        const user_id = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.user_id */ .dA.user_id];
        const formQuery = await (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .makeRequestOne */ .U)({
            url: `${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .URLS.REQUEST_FOR_QUOTATION_FORMS */ .ns.REQUEST_FOR_QUOTATION_FORMS}/${params?.id}`,
            method: "GET",
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            params: {
                fields: "id,country,currency,requested_by,full_name,user,signature,date,level,vendor_name,invoice_number,address,phone_number,bank_batch_no,delivery_period,price_validity_period,payment_terms,warrant_period,items,total,is_completed"
            }
        });
        if (!formQuery?.data) {
            // If the data is not found, return a 404 page
            return {
                notFound: true
            };
        }
        return {
            props: {
                form: formQuery?.data,
                userId: parseInt(user_id || "0")
            }
        };
    } catch (error) {
        return {
            notFound: true
        };
    }
};
SingleForm.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SingleForm);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 8277:
/***/ ((module) => {

module.exports = require("@mantine/dates");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3246:
/***/ ((module) => {

module.exports = require("mantine-datatable");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 53:
/***/ ((module) => {

module.exports = require("react-to-print");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,786,3986,2548,6193], () => (__webpack_exec__(9051)));
module.exports = __webpack_exports__;

})();