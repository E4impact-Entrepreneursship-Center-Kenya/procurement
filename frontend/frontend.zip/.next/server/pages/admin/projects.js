"use strict";
(() => {
var exports = {};
exports.id = 2130;
exports.ids = [2130,5405];
exports.modules = {

/***/ 8622:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(213);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3992);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8108);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8167);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_appProvider__WEBPACK_IMPORTED_MODULE_3__, _config_config__WEBPACK_IMPORTED_MODULE_4__]);
([_providers_appProvider__WEBPACK_IMPORTED_MODULE_3__, _config_config__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const AddNewProject = ()=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { token , user_id  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_3__/* .useAppContext */ .bp)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_1__.useForm)({
        initialValues: {
            name: "",
            code: ""
        },
        validate: {
            name: (value)=>value === "" ? "Project name is required" : null,
            code: (value)=>value === "" ? "Project code is required" : null
        }
    });
    const handleSave = ()=>{
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_4__/* .makeRequestOne */ .U)({
            url: _config_constants__WEBPACK_IMPORTED_MODULE_6__/* .URLS.PROJECTS */ .ns.PROJECTS,
            data: {
                ...form.values,
                created_by: user_id
            },
            method: "POST",
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            useNext: true
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_5__.showNotification)({
                title: "Success",
                message: "Budget Lines added successfully",
                color: "green"
            });
        }).catch((err)=>{
            const errors = err.response.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_7__/* .displayErrors */ .hP)(form, errors);
        }).finally(()=>{
            setLoading(false);
            form.reset();
            router.reload();
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Card, {
            radius: "md",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: form.onSubmit((values)=>handleSave()),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                            md: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.TextInput, {
                                label: "Project Name",
                                placeholder: "Project Name",
                                ...form.getInputProps("name")
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                            md: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.TextInput, {
                                label: "Project Code",
                                placeholder: "Project Code",
                                ...form.getInputProps("code")
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Grid.Col, {
                            md: 4,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Group, {
                                className: "h-100",
                                align: "end",
                                position: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_8__.Button, {
                                    mt: "md",
                                    type: "submit",
                                    disabled: form.values.name === "" || form.values.code === "",
                                    children: "Save Project"
                                })
                            })
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddNewProject);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(213);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__]);
_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function customRedirect(req, res) {
    (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__/* .globalLogout */ .J4)();
    res.writeHead(302, {
        location: "/auth/login/?message=no-auth"
    });
    res.end();
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (customRedirect);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9295:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_AdminWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7307);
/* harmony import */ var _middleware_requireAdminMiddleware__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6881);
/* harmony import */ var _components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9512);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8108);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3246);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(mantine_datatable__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3992);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_invoice_projects_AddNewProject__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8622);
/* harmony import */ var _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8563);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_AdminWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_projects_AddNewProject__WEBPACK_IMPORTED_MODULE_10__, _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_11__]);
([_layouts_AdminWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_projects_AddNewProject__WEBPACK_IMPORTED_MODULE_10__, _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Projects = ({ projects  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const SEO_DETAILS = {
        url: "",
        title: `${_config_constants__WEBPACK_IMPORTED_MODULE_5__/* .APP_NAME */ .iC} ${_config_constants__WEBPACK_IMPORTED_MODULE_5__/* .SEPARATOR */ .UD} Projects`,
        description: "",
        keywords: "",
        image: "",
        twitter_card: ""
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                ...SEO_DETAILS
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Title, {
                        children: "Projects"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_projects_AddNewProject__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mantine_datatable__WEBPACK_IMPORTED_MODULE_7__.DataTable, {
                        minHeight: 150,
                        records: projects,
                        columns: [
                            {
                                accessor: "id",
                                title: "#"
                            },
                            {
                                accessor: "name",
                                title: "Project Name"
                            },
                            {
                                accessor: "code",
                                title: "Project Code"
                            },
                            {
                                accessor: "created_on",
                                title: "Created On",
                                render: (project)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_6__.Text, {
                                        children: (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .toDate */ .ZU)(project?.created_on, true)
                                    })
                            },
                            {
                                accessor: "created_by.full_name",
                                title: "Created By"
                            }
                        ],
                        onRowClick: (project)=>{
                            router.push(`/admin/projects/${project?.name}/${project?.id}`);
                        }
                    })
                ]
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    (0,_middleware_requireAdminMiddleware__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
    const cookies = context.req.cookies;
    // const userDetails_: any = cookies[LOCAL_STORAGE_KEYS.token]
    const token = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_5__/* .LOCAL_STORAGE_KEYS.token */ .dA.token];
    const projectsQuery = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .makeRequestOne */ .U)({
        url: _config_constants__WEBPACK_IMPORTED_MODULE_5__/* .URLS.PROJECTS */ .ns.PROJECTS,
        method: "GET",
        params: {
            limit: 100,
            fields: "id,created_by,full_name,name,code,created_on"
        },
        extra_headers: {
            authorization: `Bearer ${token}`
        }
    });
    return Promise.allSettled([
        projectsQuery
    ]).then((res)=>{
        const projects = res[0];
        if (projects?.status === "rejected") {
            (0,_middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(context.req, context.res);
        }
        return {
            props: {
                projects: projects?.value?.data?.results
            }
        };
    });
};
Projects.PageLayout = _layouts_AdminWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Projects);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3246:
/***/ ((module) => {

module.exports = require("mantine-datatable");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,8167,134,9512], () => (__webpack_exec__(9295)));
module.exports = __webpack_exports__;

})();