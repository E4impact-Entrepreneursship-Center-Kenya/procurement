"use strict";
(() => {
var exports = {};
exports.id = 2727;
exports.ids = [2727,5405];
exports.modules = {

/***/ 8563:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(213);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__]);
_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

function customRedirect(req, res) {
    (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_0__/* .globalLogout */ .J4)();
    res.writeHead(302, {
        location: "/auth/login/?message=no-auth"
    });
    res.end();
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (customRedirect);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8108);
/* harmony import */ var _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8563);
/* harmony import */ var _middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7826);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6715);
/* harmony import */ var _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5130);
/* harmony import */ var _components_invoice_InvoiceFooter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2417);
/* harmony import */ var _components_invoice_InvoiceHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8869);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3246);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(mantine_datatable__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_invoice_initial_fields_RequestForQuotationFields__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6193);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(8167);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(213);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_5__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_9__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_19__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _config_config__WEBPACK_IMPORTED_MODULE_3__, _middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_5__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_9__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




















const SINGLE_ITEM = {
    no: "",
    description: "",
    qty: "",
    unit: "",
    unit_price: "",
    amount: ""
};
const RequestForQuotationDatatable = ({ form  })=>{
    function addItem() {
        form.insertListItem("items", SINGLE_ITEM);
    }
    function removeItem(index) {
        form.removeListItem("items", index);
    }
    const getTotal = (units, rate, index)=>{
        if (units && units !== "" && rate && rate !== "") {
            const amt = parseFloat(units) * parseFloat(rate);
            form.setFieldValue(`items.${index}.amount`, amt);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mantine_datatable__WEBPACK_IMPORTED_MODULE_15__.DataTable, {
                horizontalSpacing: "xs",
                verticalSpacing: "md",
                minHeight: 150,
                records: form.values.items,
                columns: [
                    {
                        accessor: "no",
                        title: "No.",
                        width: "60px",
                        noWrap: true,
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.NumberInput, {
                                hideControls: true,
                                ...form.getInputProps(`items.${i}.no`),
                                placeholder: "No."
                            });
                        }
                    },
                    {
                        title: "Item Description",
                        accessor: "description",
                        width: "250px",
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                                ...form.getInputProps(`items.${i}.description`),
                                placeholder: "Give a description of this item"
                            });
                        }
                    },
                    {
                        title: "Unit",
                        accessor: "unit",
                        width: "60px",
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                                ...form.getInputProps(`items.${i}.unit`),
                                placeholder: "KG, PC, LTR"
                            });
                        }
                    },
                    {
                        title: "Quantity",
                        accessor: "qty",
                        width: "80px",
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.NumberInput, {
                                hideControls: true,
                                ...form.getInputProps(`items.${i}.qty`),
                                placeholder: "20",
                                onBlur: (el)=>getTotal(form.values.items[i].qty, form.values.items[i].unit_price, i)
                            });
                        }
                    },
                    {
                        title: "Unit Price",
                        accessor: "unit_price",
                        width: "60px",
                        ellipsis: false,
                        // noWrap: false,
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.NumberInput, {
                                hideControls: true,
                                ...form.getInputProps(`items.${i}.unit_price`),
                                placeholder: "20",
                                onBlur: (el)=>getTotal(form.values.items[i].qty, form.values.items[i].unit_price, i)
                            });
                        }
                    },
                    {
                        title: "Total Cost (KSH)",
                        accessor: "amount",
                        width: "100px",
                        render: (entry, i)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.NumberInput, {
                                disabled: true,
                                icon: "KSH",
                                thousandsSeparator: ",",
                                hideControls: true,
                                ...form.getInputProps(`items.${i}.amount`),
                                parser: (value)=>value.replace(/\$\s?|(,*)/g, "")
                            });
                        }
                    },
                    {
                        accessor: "actions",
                        title: "",
                        width: "40px",
                        render: (item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Group, {
                                position: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.ActionIcon, {
                                    color: "red",
                                    variant: "light",
                                    onClick: (e)=>removeItem(i),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__.IconTrash, {})
                                })
                            })
                    }
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Group, {
                position: "right",
                mt: "md",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Button, {
                    radius: "md",
                    leftIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__.IconPlus, {}),
                    onClick: addItem,
                    children: "Add Item"
                })
            })
        ]
    });
};
const ExtraFields = ({ form  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Grid, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Grid.Col, {
                md: 6,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                    label: "Payment Terms",
                    placeholder: "Payment Terms",
                    ...form.getInputProps("payment_terms")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Grid.Col, {
                md: 6,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                    label: "Delivery period",
                    placeholder: "Duration for delivery of items",
                    ...form.getInputProps("delivery_period")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Grid.Col, {
                md: 6,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                    label: "Price validity period",
                    placeholder: "Price validity period",
                    ...form.getInputProps("price_validity_period")
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Grid.Col, {
                md: 6,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.TextInput, {
                    label: "Warranty period",
                    placeholder: "Where applicable",
                    ...form.getInputProps("warrant_period")
                })
            })
        ]
    });
};
const RequestForQuotation = ({ projects , checkers , user  })=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_19__/* .useAppContext */ .bp)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_13__.useForm)({
        initialValues: {
            country: "",
            currency: "",
            invoice_number: "",
            bank_batch_no: "",
            vendor_name: "",
            address: "",
            phone_number: "",
            items: Array(1).fill(SINGLE_ITEM),
            payment_terms: "",
            delivery_period: "",
            price_validity_period: "",
            warrant_period: "",
            requested_by: {
                user: "",
                signature: "",
                date: ""
            }
        }
    });
    function getAmountTotal(items) {
        if (items) {
            return items?.reduce((old, item, i)=>item?.amount !== "" || item?.amount !== null ? old + item?.amount : old, 0);
        }
        return form.values?.items?.reduce((old, item, i)=>item?.amount !== "" || item?.amount !== null ? old + item?.amount : old, 0);
    }
    function submitForm() {
        let data = structuredClone(form.values);
        data.requested_by.user = user_id;
        let items = data.items.filter((ln)=>ln?.description !== "");
        if (items.length === 0) {
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_17__.showNotification)({
                title: "No items",
                message: "You don't have any items in your form",
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__.IconExclamationMark, {})
            });
            return;
        }
        setLoading(true);
        data.total = getAmountTotal(data.items);
        data.items = JSON.stringify(items);
        let requested_by_date = (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .formatDateToYYYYMMDD */ .bm)(data.requested_by.date);
        data.requested_by.date = requested_by_date;
        const formData = (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .convertJSONToFormData */ .w6)(data);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .makeRequestOne */ .U)({
            url: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .URLS.REQUEST_FOR_QUOTATION_FORMS */ .ns.REQUEST_FOR_QUOTATION_FORMS,
            method: "POST",
            data: formData,
            extra_headers: {
                authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data"
            }
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_17__.showNotification)({
                title: `Submission successful ${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .EMOJIS.partypopper */ .V6.partypopper}`,
                message: "Congratulations! Your form has been submitted successfully",
                color: "green",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__.IconInfoCircle, {})
            });
            form.reset();
        }).catch((err)=>{
            const errors = err?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_18__/* .displayErrors */ .hP)(form, errors);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_17__.showNotification)({
                title: "Error",
                message: "Unable to complete your request at this time! Try again later",
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_14__.IconInfoCircle, {})
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_12___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: `${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .APP_NAME */ .iC} ${_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .SEPARATOR */ .UD} Request For Quotation Form`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Container, {
                size: "lg",
                mt: 20,
                my: "lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Paper, {
                    py: 30,
                    px: 30,
                    radius: "md",
                    sx: (theme)=>({
                            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .getTheme */ .gh)(theme) ? theme.colors.dark[6] : theme.colors.gray[0]
                        }),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.LoadingOverlay, {
                            visible: loading
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: form.onSubmit((values)=>submitForm()),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Stack, {
                                spacing: 20,
                                children: [
                                    form.values.country?.toLowerCase() === "kenya" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Image, {
                                        mx: "auto",
                                        src: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .WEBSITE_LOGO */ .S0,
                                        width: 250,
                                        alt: "E4I Invoice"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Image, {
                                        mx: "auto",
                                        src: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .FOUNDATION_LOGO */ .nA,
                                        width: 250,
                                        alt: "E4I Invoice"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_InvoiceHeader__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                        title: `REQUEST FOR QUOTATION FORM (${form.values?.currency?.toUpperCase()})`,
                                        form: form
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_initial_fields_RequestForQuotationFields__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                        form: form,
                                        projects: projects
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RequestForQuotationDatatable, {
                                        form: form
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Group, {
                                        position: "right",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Title, {
                                                order: 3,
                                                weight: 600,
                                                children: "Total"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Title, {
                                                order: 3,
                                                weight: 600,
                                                children: `KSH ${(0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .formatCurrency */ .xG)(getAmountTotal())}`
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ExtraFields, {
                                        form: form
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                            person: "Requested By",
                                            form: form,
                                            field_prefix: "requested_by",
                                            field_name: "user",
                                            active: true,
                                            level: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .INVOICE_LEVELS.LEVEL_1 */ .kt.LEVEL_1
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_InvoiceFooter__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Group, {
                                        position: "center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_7__.Button, {
                                            type: "submit",
                                            children: "Submit"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    (0,_middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
    const cookies = context.req.cookies;
    const userDetails_ = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.user */ .dA.user];
    const user = JSON.parse(userDetails_ ?? "null");
    const token = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_4__/* .LOCAL_STORAGE_KEYS.token */ .dA.token];
    const projectsQuery = (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .makeRequestOne */ .U)({
        url: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .URLS.PROJECTS */ .ns.PROJECTS,
        method: "GET",
        params: {
            limit: 100,
            fields: "id,created_by,full_name,name,code,created_on"
        },
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        useNext: true
    });
    const checkersQuery = (0,_config_config__WEBPACK_IMPORTED_MODULE_3__/* .makeRequestOne */ .U)({
        url: _config_constants__WEBPACK_IMPORTED_MODULE_4__/* .URLS.USERS */ .ns.USERS,
        method: "GET",
        params: {
            limit: 100,
            fields: "id,full_name",
            profile__checker: true
        },
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        useNext: true
    });
    return Promise.allSettled([
        projectsQuery,
        checkersQuery
    ]).then((res)=>{
        const projects = res[0];
        const checkers = res[1];
        if (projects?.status === "rejected") {
            (0,_middleware_redirectIfNoAuth__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)(context.req, context.res);
        }
        return {
            props: {
                projects: projects?.value?.data?.results,
                checkers: checkers?.value?.data?.results,
                user: user ? user.full_name : null
            }
        };
    });
};
RequestForQuotation.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RequestForQuotation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 8277:
/***/ ((module) => {

module.exports = require("@mantine/dates");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3246:
/***/ ((module) => {

module.exports = require("mantine-datatable");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,786,3986,6193], () => (__webpack_exec__(4103)));
module.exports = __webpack_exports__;

})();