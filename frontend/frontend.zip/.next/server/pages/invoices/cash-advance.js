"use strict";
(() => {
var exports = {};
exports.id = 1394;
exports.ids = [1394,5405];
exports.modules = {

/***/ 2398:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8108);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1463);
/* harmony import */ var _components_invoice_InvoiceHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8869);
/* harmony import */ var _components_invoice_InvoiceFooter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2417);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3992);
/* harmony import */ var _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6715);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3246);
/* harmony import */ var mantine_datatable__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(mantine_datatable__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_invoice_initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1415);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(213);
/* harmony import */ var _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(5130);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8167);
/* harmony import */ var _middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(7826);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_5__, _config_config__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__, _components_invoice_initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_13__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_14__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_15__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_5__, _config_config__WEBPACK_IMPORTED_MODULE_8__, _components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__, _components_invoice_initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_13__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_14__, _components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const SINGLE_ITEM = {
    no: "",
    description: "",
    budget_line: "",
    unit: "",
    no_of_units: "",
    unit_rate: "",
    amount: ""
};
const CashAdvance = ({ projects , user , checkers  })=>{
    const [budgetLines, setBudgetLines] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { user_id , token  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_14__/* .useAppContext */ .bp)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_10__.useForm)({
        initialValues: {
            level: 1,
            country: "Kenya",
            currency: "kes",
            invoice_number: "",
            name: user ? user : "",
            date: "",
            purpose: "",
            project: "",
            code: "",
            activity_end_date: "",
            expected_liquidation_date: "",
            items: Array(1).fill(SINGLE_ITEM),
            requested_by: {
                user: user,
                signature: "",
                date: ""
            },
            checker: ""
        },
        validate: {
            expected_liquidation_date: (value)=>value === "" ? "Select date" : null,
            activity_end_date: (value)=>value === "" ? "Select date" : null,
            date: (value)=>value === "" ? "Select date" : null,
            purpose: (value)=>value === "" ? "Enter Purpose" : null,
            project: (value)=>value === "" ? "Select Project" : null,
            items: {
                no: (value)=>value === "" ? "No is required" : null,
                description: (value)=>value === "" ? "Description is required" : null,
                budget_line: (value)=>value === "" ? "Select Budget line" : null,
                no_of_units: (value)=>value === "" ? "Units Count is required" : null,
                unit_rate: (value)=>value === "" ? "Unit Rate is required" : null
            },
            requested_by: {
                user: (value)=>value === "" ? "Enter Your Name" : null,
                signature: (value)=>value === "" || value === null ? "Upload your Signature" : null,
                date: (value)=>value === "" ? "Select Date" : null
            },
            checker: (value)=>value === "" ? "Select who to check the form" : null
        }
    });
    const getTotal = (units, rate, index)=>{
        if (units && units !== "" && rate && rate !== "") {
            const amt = parseFloat(units) * parseFloat(rate);
            form.setFieldValue(`items.${index}.amount`, amt);
        }
    };
    function addItem() {
        form.insertListItem("items", SINGLE_ITEM);
    }
    function removeItem(index) {
        form.removeListItem("items", index);
    }
    function getAmountTotal(items) {
        if (items) {
            return items?.reduce((old, item, i)=>item?.amount !== "" || item?.amount !== null ? old + item?.amount : old, 0);
        }
        return form.values?.items?.reduce((old, item, i)=>item?.amount !== "" || item?.amount !== null ? old + item?.amount : old, 0);
    }
    function loadBudgetLines() {
        (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .makeRequestOne */ .U)({
            url: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .URLS.BUDGET_LINES */ .ns.BUDGET_LINES,
            method: "GET",
            extra_headers: {
                authorization: `Bearer ${token}`
            },
            params: {
                project: form.values.project,
                fields: "id,code",
                limit: 150
            }
        }).then((res)=>{
            setBudgetLines(res?.data?.results);
        }).catch(()=>{});
    }
    function submitForm() {
        let data = structuredClone(form.values);
        data.requested_by.user = user_id;
        let items = data.items.filter((ln)=>ln?.description !== "");
        if (items.length === 0) {
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_16__.showNotification)({
                title: "No items",
                message: "You don't have any items in your form",
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconExclamationMark, {})
            });
            return;
        }
        setLoading(true);
        data.total = getAmountTotal(data.items);
        data.items = JSON.stringify(items);
        data.date = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .formatDateToYYYYMMDD */ .bm)(data?.date);
        data.activity_end_date = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .formatDateToYYYYMMDD */ .bm)(data?.activity_end_date);
        data.expected_liquidation_date = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .formatDateToYYYYMMDD */ .bm)(data?.expected_liquidation_date);
        let requested_by_date = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .formatDateToYYYYMMDD */ .bm)(data.requested_by.date);
        data.requested_by.date = requested_by_date;
        const formData = (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .convertJSONToFormData */ .w6)(data);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .makeRequestOne */ .U)({
            url: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .URLS.CASH_ADVANCE_FORMS */ .ns.CASH_ADVANCE_FORMS,
            method: "POST",
            data: formData,
            extra_headers: {
                authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data"
            }
        }).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_16__.showNotification)({
                title: `Submission successful ${_config_constants__WEBPACK_IMPORTED_MODULE_3__/* .EMOJIS.partypopper */ .V6.partypopper}`,
                message: "Congratulations! Your form has been submitted successfully",
                color: "green",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconInfoCircle, {})
            });
            form.reset();
        }).catch((err)=>{
            const errors = err?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_17__/* .displayErrors */ .hP)(form, errors);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_16__.showNotification)({
                title: "Error",
                message: "Unable to complete your request at this time! Try again later",
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconInfoCircle, {})
            });
        }).finally(()=>{
            setLoading(false);
        });
    }
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        loadBudgetLines();
    }, [
        form.values.project
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                    children: `${_config_constants__WEBPACK_IMPORTED_MODULE_3__/* .APP_NAME */ .iC} ${_config_constants__WEBPACK_IMPORTED_MODULE_3__/* .SEPARATOR */ .UD} Cash Advance`
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Container, {
                size: "lg",
                mt: 20,
                my: "lg",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Paper, {
                    py: 30,
                    px: 30,
                    radius: "md",
                    sx: (theme)=>({
                            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .getTheme */ .gh)(theme) ? theme.colors.dark[6] : theme.colors.gray[0]
                        }),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.LoadingOverlay, {
                            visible: loading
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                            onSubmit: form.onSubmit((values)=>submitForm()),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                spacing: 20,
                                children: [
                                    form.values.country?.toLowerCase() === "kenya" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Image, {
                                        mx: "auto",
                                        src: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .WEBSITE_LOGO */ .S0,
                                        width: 250,
                                        alt: "E4I Invoice"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Image, {
                                        mx: "auto",
                                        src: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .FOUNDATION_LOGO */ .nA,
                                        width: 250,
                                        alt: "E4I Invoice"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_InvoiceHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        title: `CASH/ADVANCE REQUEST FORM  (${form.values?.currency?.toUpperCase()})`,
                                        form: form
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_initial_fields_InvoiceInitialFieldsCashAdvance__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                        form: form,
                                        projects: projects
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Paper, {
                                        p: "md",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                            spacing: 10,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(mantine_datatable__WEBPACK_IMPORTED_MODULE_11__.DataTable, {
                                                    horizontalSpacing: "xs",
                                                    verticalSpacing: "md",
                                                    minHeight: 150,
                                                    records: form.values.items,
                                                    columns: [
                                                        {
                                                            accessor: "no",
                                                            title: "No.",
                                                            width: "60px",
                                                            noWrap: true,
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.NumberInput, {
                                                                    hideControls: true,
                                                                    ...form.getInputProps(`items.${i}.no`),
                                                                    placeholder: "No."
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: "DESCRIPTION",
                                                            accessor: "description",
                                                            width: "250px",
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.TextInput, {
                                                                    ...form.getInputProps(`items.${i}.description`),
                                                                    placeholder: "Give a description of this item"
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: "BUDGET LINE",
                                                            accessor: "budget_line",
                                                            width: "100px",
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                                                    searchable: true,
                                                                    placeholder: "Budget Line",
                                                                    data: budgetLines ? budgetLines?.map((line)=>({
                                                                            value: line?.code,
                                                                            label: `${line?.code} ${line?.text}`
                                                                        })) : [],
                                                                    ...form.getInputProps(`items.${i}.budget_line`)
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: "UNIT",
                                                            accessor: "unit",
                                                            width: "60px",
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.TextInput, {
                                                                    ...form.getInputProps(`items.${i}.unit`),
                                                                    placeholder: "KG, PC, LTR"
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: "NO. OF UNIT(S)",
                                                            accessor: "no_of_units",
                                                            width: "80px",
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.NumberInput, {
                                                                    hideControls: true,
                                                                    ...form.getInputProps(`items.${i}.no_of_units`),
                                                                    placeholder: "20",
                                                                    onBlur: (el)=>getTotal(form.values.items[i].no_of_units, form.values.items[i].unit_rate, i)
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: "UNIT RATE",
                                                            accessor: "unit_rate",
                                                            width: "60px",
                                                            ellipsis: false,
                                                            // noWrap: false,
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.NumberInput, {
                                                                    hideControls: true,
                                                                    ...form.getInputProps(`items.${i}.unit_rate`),
                                                                    placeholder: "20",
                                                                    onBlur: (el)=>getTotal(form.values.items[i].no_of_units, form.values.items[i].unit_rate, i)
                                                                });
                                                            }
                                                        },
                                                        {
                                                            title: `TOTAL AMOUNT (${form.values?.currency?.toUpperCase()})`,
                                                            accessor: "amount",
                                                            width: "100px",
                                                            render: (entry, i)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.NumberInput, {
                                                                    disabled: true,
                                                                    thousandsSeparator: ",",
                                                                    ...form.getInputProps(`items.${i}.amount`),
                                                                    parser: (value)=>value.replace(/\$\s?|(,*)/g, ""),
                                                                    formatter: (value)=>!Number.isNaN(parseFloat(value)) ? `${form.values?.currency?.toUpperCase()} ${value}`.replace(/\B(?<!\.\d*)(?=(\d{3})+(?!\d))/g, ",") : `${form.values?.currency?.toUpperCase()} `
                                                                });
                                                            }
                                                        },
                                                        {
                                                            accessor: "actions",
                                                            title: "",
                                                            width: "40px",
                                                            render: (item, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Group, {
                                                                    position: "center",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.ActionIcon, {
                                                                        color: "red",
                                                                        variant: "light",
                                                                        onClick: (e)=>removeItem(i),
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconTrash, {})
                                                                    })
                                                                })
                                                        }
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Group, {
                                                    position: "right",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                        radius: "md",
                                                        leftIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_12__.IconPlus, {}),
                                                        onClick: addItem,
                                                        children: "Add Item"
                                                    })
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Group, {
                                                    position: "right",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Title, {
                                                            order: 3,
                                                            weight: 600,
                                                            children: "Total"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Title, {
                                                            order: 3,
                                                            weight: 600,
                                                            children: `${form.values?.currency?.toUpperCase()} ${(0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .formatCurrency */ .xG)(getAmountTotal())}`
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_invoice_ApprovalsSection__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                person: "Requested By",
                                                form: form,
                                                field_prefix: "requested_by",
                                                field_name: "user",
                                                active: true,
                                                level: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .INVOICE_LEVELS.LEVEL_1 */ .kt.LEVEL_1
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                py: "lg",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Select, {
                                                    searchable: true,
                                                    label: "Who is to check the form?",
                                                    data: checkers?.map((checker)=>({
                                                            value: checker?.id?.toString(),
                                                            label: checker?.full_name || "No name"
                                                        })) || [],
                                                    ...form.getInputProps("checker")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                person: "Checked By",
                                                form: form,
                                                field_prefix: "checked_by",
                                                field_name: "user",
                                                active: false,
                                                level: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .INVOICE_LEVELS.LEVEL_1 */ .kt.LEVEL_1
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                person: "Approved By",
                                                form: form,
                                                field_prefix: "approved_by",
                                                field_name: "user",
                                                active: false,
                                                level: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .INVOICE_LEVELS.LEVEL_1 */ .kt.LEVEL_1
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_Approvals__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                                person: "Amount Received",
                                                form: form,
                                                field_prefix: "amount_received",
                                                field_name: "amount",
                                                active: false,
                                                level: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .INVOICE_LEVELS.LEVEL_1 */ .kt.LEVEL_1
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_invoice_InvoiceFooter__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Group, {
                                        position: "center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                            type: "submit",
                                            children: "Submit"
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    (0,_middleware_requireAuthMiddleware__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)(context.req, context.res, ()=>{});
    const cookies = context.req.cookies;
    const userDetails_ = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_3__/* .LOCAL_STORAGE_KEYS.user */ .dA.user];
    const user = JSON.parse(userDetails_ ?? "null");
    const token = cookies[_config_constants__WEBPACK_IMPORTED_MODULE_3__/* .LOCAL_STORAGE_KEYS.token */ .dA.token];
    const projectsQuery = await (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .makeRequestOne */ .U)({
        url: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .URLS.PROJECTS */ .ns.PROJECTS,
        method: "GET",
        params: {
            limit: 100,
            fields: "id,created_by,full_name,name,code,created_on"
        },
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        useNext: true
    });
    const checkersQuery = await (0,_config_config__WEBPACK_IMPORTED_MODULE_8__/* .makeRequestOne */ .U)({
        url: _config_constants__WEBPACK_IMPORTED_MODULE_3__/* .URLS.USERS */ .ns.USERS,
        method: "GET",
        params: {
            limit: 100,
            fields: "id,full_name",
            profile__checker: true
        },
        extra_headers: {
            authorization: `Bearer ${token}`
        },
        useNext: true
    });
    return {
        props: {
            projects: projectsQuery?.data?.results,
            checkers: checkersQuery?.data?.results,
            user: user ? user.full_name : null
        }
    };
};
CashAdvance.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CashAdvance);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 8277:
/***/ ((module) => {

module.exports = require("@mantine/dates");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3246:
/***/ ((module) => {

module.exports = require("mantine-datatable");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,786,3986,1415], () => (__webpack_exec__(2398)));
module.exports = __webpack_exports__;

})();