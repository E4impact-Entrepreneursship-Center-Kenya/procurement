"use strict";
(() => {
var exports = {};
exports.id = 6616;
exports.ids = [6616,5405];
exports.modules = {

/***/ 7316:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6116);
/* harmony import */ var _components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6004);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1463);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8167);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_styles_publicStyles__WEBPACK_IMPORTED_MODULE_9__, _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_11__, _config_config__WEBPACK_IMPORTED_MODULE_12__]);
([_styles_publicStyles__WEBPACK_IMPORTED_MODULE_9__, _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_11__, _config_config__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Reset = (props)=>{
    const { loginStatus  } = props;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { classes , theme  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_7__.useForm)({
        initialValues: {
            email: ""
        },
        validate: {
            email: (value)=>value === "" ? "Email is required" : null
        }
    });
    const handlePasswordReset = ()=>{
        const options = {
            url: `${_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .URLS.REQUEST_PASSWORD_RESET */ .ns.REQUEST_PASSWORD_RESET}`,
            method: "POST",
            extra_headers: {},
            data: {
                ...form.values
            },
            params: {},
            useNext: true
        };
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .makeRequestOne */ .U)(options).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__.showNotification)({
                title: "Success",
                message: "An email has been sent with further instructions to reset your password.",
                color: "green",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconAlertCircle, {
                    stroke: 1.5
                })
            });
            form.reset();
        }).catch((error)=>{
            const errors = error?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_14__/* .displayErrors */ .hP)(form, errors);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__.showNotification)({
                title: "Error",
                message: "An error occurred. Please try again",
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconAlertTriangle, {
                    stroke: 1.5
                })
            });
        }).finally(()=>{
            setLoading(false);
        });
    };
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (loginStatus) {
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_8__.showNotification)({
                title: "You are Authenticated",
                message: "You are already logged in",
                color: "yellow",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconAlertOctagon, {
                    stroke: 1.5
                })
            });
            router.push("/");
        }
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Box, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Container, {
                size: "xs",
                py: 50,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Card, {
                    radius: "lg",
                    p: 50,
                    style: {
                        background: (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[0],
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.LoadingOverlay, {
                            visible: loading
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Center, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Image, {
                                        src: _config_constants__WEBPACK_IMPORTED_MODULE_13__/* .WEBSITE_LOGO */ .S0,
                                        radius: "md",
                                        className: classes.image,
                                        width: 200
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Title, {
                                    className: classes.title2,
                                    align: "center",
                                    children: "Reset Password"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                    align: "center",
                                    children: "Please fill in the form below to reset your password"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                    onSubmit: form.onSubmit((values)=>handlePasswordReset()),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Grid.Col, {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.TextInput, {
                                                    label: "Email",
                                                    placeholder: "Enter your email",
                                                    type: "email",
                                                    radius: "md",
                                                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconMail, {
                                                        stroke: 1.5
                                                    }),
                                                    autoFocus: true,
                                                    ...form.getInputProps("email")
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Grid.Col, {
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                                                    align: "center",
                                                    spacing: 16,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_10__/* .CallToActionButtonAction */ .LG, {
                                                            label: "Request Password Reset",
                                                            type: "submit",
                                                            icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_3__.IconPassword, {
                                                                stroke: 1.5,
                                                                color: "white"
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Group, {
                                                            spacing: 4,
                                                            p: 0,
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Text, {
                                                                    size: "sm",
                                                                    children: "Remember your password?"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_2__.Anchor, {
                                                                    component: (next_link__WEBPACK_IMPORTED_MODULE_4___default()),
                                                                    href: "/auth/login",
                                                                    size: "sm",
                                                                    children: "Sign In"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};
async function getServerSideProps(context) {
    const status = (0,cookies_next__WEBPACK_IMPORTED_MODULE_5__.getCookie)(_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .LOCAL_STORAGE_KEYS.login_status */ .dA.login_status, context);
    return {
        props: {
            loginStatus: status ? status : false
        }
    };
}
Reset.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Reset);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,6004], () => (__webpack_exec__(7316)));
module.exports = __webpack_exports__;

})();