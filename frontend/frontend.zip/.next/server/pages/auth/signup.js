"use strict";
(() => {
var exports = {};
exports.id = 5613;
exports.ids = [5613,5405];
exports.modules = {

/***/ 8606:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_CustomPasswordInput)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "@tabler/icons-react"
const icons_react_namespaceObject = require("@tabler/icons-react");
// EXTERNAL MODULE: external "@mantine/core"
var core_ = __webpack_require__(2247);
;// CONCATENATED MODULE: ./components/auth/CustomPasswordInput.tsx




function PasswordRequirement({ meets , label  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Text, {
        color: meets ? "teal" : "red",
        sx: {
            display: "flex",
            alignItems: "center"
        },
        mt: 7,
        size: "sm",
        children: [
            meets ? /*#__PURE__*/ jsx_runtime_.jsx(icons_react_namespaceObject.IconCheck, {
                size: "0.9rem"
            }) : /*#__PURE__*/ jsx_runtime_.jsx(icons_react_namespaceObject.IconX, {
                size: "0.9rem"
            }),
            " ",
            /*#__PURE__*/ jsx_runtime_.jsx(core_.Box, {
                ml: 10,
                children: label
            })
        ]
    });
}
const requirements = [
    {
        re: /[0-9]/,
        label: "Includes number"
    },
    {
        re: /[a-z]/,
        label: "Includes lowercase letter"
    },
    {
        re: /[A-Z]/,
        label: "Includes uppercase letter"
    },
    {
        re: /[$&+,:;=?@#|'<>.^*()%!-]/,
        label: "Includes special symbol"
    }
];
function getStrength(password) {
    let multiplier = password.length > 7 ? 0 : 1;
    requirements.forEach((requirement)=>{
        if (!requirement.re.test(password)) {
            multiplier += 1;
        }
    });
    return Math.max(100 - 100 / (requirements.length + 1) * multiplier, 10);
}
function CustomPasswordInput(props) {
    const { form , fieldName , label  } = props;
    const [popoverOpened, setPopoverOpened] = (0,external_react_.useState)(false);
    const value = form.values[fieldName];
    const checks = requirements.map((requirement, index)=>/*#__PURE__*/ jsx_runtime_.jsx(PasswordRequirement, {
            label: requirement.label,
            meets: requirement.re.test(value)
        }, index));
    const strength = getStrength(value);
    const color = strength === 100 ? "teal" : strength > 50 ? "yellow" : "red";
    return /*#__PURE__*/ jsx_runtime_.jsx(core_.Box, {
        mx: "auto",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Popover, {
            opened: popoverOpened,
            position: "bottom",
            width: "target",
            transitionProps: {
                transition: "pop"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(core_.Popover.Target, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        onFocusCapture: ()=>setPopoverOpened(true),
                        onBlurCapture: ()=>setPopoverOpened(false),
                        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.PasswordInput, {
                            radius: "md",
                            withAsterisk: true,
                            label: label,
                            placeholder: "Enter Password",
                            icon: /*#__PURE__*/ jsx_runtime_.jsx(icons_react_namespaceObject.IconPassword, {
                                stroke: 1.5
                            }),
                            value: value,
                            ...form.getInputProps(fieldName)
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(core_.Popover.Dropdown, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(core_.Progress, {
                            color: color,
                            value: strength,
                            size: 5,
                            mb: "xs"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(PasswordRequirement, {
                            label: "Includes at least 8 characters",
                            meets: value.length > 7
                        }),
                        checks
                    ]
                })
            ]
        })
    });
}
/* harmony default export */ const auth_CustomPasswordInput = (CustomPasswordInput);


/***/ }),

/***/ 8444:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6116);
/* harmony import */ var _components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6004);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(213);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8167);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9512);
/* harmony import */ var _components_auth_CustomPasswordInput__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(8606);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_9__, _config_config__WEBPACK_IMPORTED_MODULE_12__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_9__, _config_config__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const SignUp = (props)=>{
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { login_status  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_9__/* .useAppContext */ .bp)();
    const { classes  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const theme = (0,_mantine_core__WEBPACK_IMPORTED_MODULE_3__.useMantineTheme)();
    const emailRegex = /[A-Za-z0-9._%+-]+@e4impact\.org/gi;
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_15__.useForm)({
        initialValues: {
            username: "",
            first_name: "",
            last_name: "",
            email: "",
            profile: {
                // profile_photo: '',
                phone_no: ""
            },
            password: "",
            password2: ""
        },
        validate: {
            username: (value)=>value === "" ? "Username is required" : null,
            first_name: (value)=>value === "" ? "First name is required" : null,
            last_name: (value)=>value === "" ? "Last name is required" : null,
            email: (value)=>{
                if (value === "") {
                    return "Email is required";
                } else if (!emailRegex.test(value)) {
                    return "Only E4Impact emails are required!";
                }
                return null;
            },
            password: (value)=>{
                if (value === "") {
                    return "Password is required";
                }
                if (value.length < 8) {
                    return "Password must be at least 8 characters long";
                }
                if (value !== form.values.password2) {
                    return "Passwords do not match";
                }
                return null;
            },
            password2: (value)=>value === "" ? "Password confirmation is required" : null
        }
    });
    const handleSignup = ()=>{
        const requestOptions = {
            url: `${_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .URLS.REGISTER */ .ns.REGISTER}`,
            method: "POST",
            extra_headers: {},
            data: form.values,
            params: {},
            useNext: true
        };
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .makeRequestOne */ .U)(requestOptions).then((res)=>{
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_11__.showNotification)({
                title: `Congratulations ${_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .EMOJIS.partypopper */ .V6.partypopper} ${_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .EMOJIS.partypopper */ .V6.partypopper}`,
                message: "Account created successfully. Please login to continue",
                color: "green",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconAlertCircle, {
                    stroke: 1.5
                })
            });
            router.push("/auth/login");
        }).catch((error)=>{
            const errors = error?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_14__/* .displayErrors */ .hP)(form, errors);
            (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_11__.showNotification)({
                title: "Error",
                message: error?.message,
                color: "red",
                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconAlertTriangle, {
                    stroke: 1.5
                })
            });
        }).finally(()=>{
            setLoading(false);
        });
    };
    const seoDetails = {
        url: "/auth/signup",
        title: "Sign Up",
        description: "Create a new account",
        keywords: "",
        image: "",
        twitter_card: ""
    };
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (login_status) {
            router.push("/");
        }
    }, [
        login_status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                ...seoDetails
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Container, {
                    size: "xs",
                    py: 50,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Card, {
                        radius: "lg",
                        p: 50,
                        style: {
                            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[0],
                            position: "relative"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.LoadingOverlay, {
                                visible: loading
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Center, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Image, {
                                            src: _config_constants__WEBPACK_IMPORTED_MODULE_13__/* .WEBSITE_LOGO */ .S0,
                                            radius: "md",
                                            className: classes.image,
                                            width: 200
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Title, {
                                        className: classes.title2,
                                        align: "center",
                                        children: "Sign Up"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        align: "center",
                                        children: "Create a new free account."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                        onSubmit: form.onSubmit((values)=>handleSignup()),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "First Name",
                                                        placeholder: "Enter your first name",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconUser, {
                                                            stroke: 1.5
                                                        }),
                                                        autoFocus: true,
                                                        ...form.getInputProps("first_name")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "Last Name",
                                                        placeholder: "Enter your last name",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconUser, {
                                                            stroke: 1.5
                                                        }),
                                                        ...form.getInputProps("last_name")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "Email",
                                                        placeholder: "Enter your email",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconMail, {
                                                            stroke: 1.5
                                                        }),
                                                        ...form.getInputProps("email")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "Username",
                                                        placeholder: "Enter your username",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconUser, {
                                                            stroke: 1.5
                                                        }),
                                                        ...form.getInputProps("username")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "Phone Number",
                                                        placeholder: "Enter your phone number",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconPhone, {
                                                            stroke: 1.5
                                                        }),
                                                        ...form.getInputProps("profile.phone_no")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_auth_CustomPasswordInput__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                        form: form,
                                                        fieldName: "password",
                                                        label: "Password"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    md: 6,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_auth_CustomPasswordInput__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                                        form: form,
                                                        fieldName: "password2",
                                                        label: "Repeat Password"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                                        align: "center",
                                                        spacing: 16,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_5__/* .CallToActionButtonAction */ .LG, {
                                                                label: "Create Account",
                                                                type: "submit",
                                                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconUserPlus, {
                                                                    stroke: 1.5,
                                                                    color: "white"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Group, {
                                                                spacing: 4,
                                                                p: 0,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                                        size: "sm",
                                                                        children: "Already have an account?"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Anchor, {
                                                                        component: (next_link__WEBPACK_IMPORTED_MODULE_7___default()),
                                                                        href: "/auth/login",
                                                                        size: "sm",
                                                                        children: "Login"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
SignUp.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
async function getServerSideProps(context) {
    const status = (0,cookies_next__WEBPACK_IMPORTED_MODULE_8__.getCookie)(_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .LOCAL_STORAGE_KEYS.login_status */ .dA.login_status, context);
    return {
        props: {
            loginStatus: status ? status : null
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SignUp);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,6004,9512], () => (__webpack_exec__(8444)));
module.exports = __webpack_exports__;

})();