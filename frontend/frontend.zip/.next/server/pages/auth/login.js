"use strict";
(() => {
var exports = {};
exports.id = 9344;
exports.ids = [9344,5405];
exports.modules = {

/***/ 1881:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1463);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2247);
/* harmony import */ var _mantine_core__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mantine_core__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6116);
/* harmony import */ var _components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6004);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4116);
/* harmony import */ var _tabler_icons__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(213);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8982);
/* harmony import */ var cookies_next__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(cookies_next__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9445);
/* harmony import */ var _mantine_form__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mantine_form__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _config_config__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(3992);
/* harmony import */ var _config_constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8108);
/* harmony import */ var _config_functions__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8167);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(914);
/* harmony import */ var _mantine_notifications__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mantine_notifications__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9512);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__, _config_config__WEBPACK_IMPORTED_MODULE_12__]);
([_layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__, _styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__, _providers_appProvider__WEBPACK_IMPORTED_MODULE_8__, _config_config__WEBPACK_IMPORTED_MODULE_12__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const Login = (props)=>{
    const { login , login_status , user  } = (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_8__/* .useAppContext */ .bp)();
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { classes , theme  } = (0,_styles_publicStyles__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { replace , push , query , pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const form = (0,_mantine_form__WEBPACK_IMPORTED_MODULE_11__.useForm)({
        initialValues: {
            username: "",
            password: ""
        },
        validate: {
            username: (value)=>value === "" ? "Username is required" : null,
            password: (value)=>value === "" ? "Password is required" : null
        }
    });
    const handleLogin = ()=>{
        const requestOptions = {
            url: `${_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .URLS.LOGIN */ .ns.LOGIN}`,
            method: "POST",
            extra_headers: {},
            data: form.values,
            params: {
                fields: "id,username,full_name,is_superuser,profile,phone_no,checker,approver,can_update_bank_batch,is_finance_officer,can_verify_purchases"
            },
            useNext: true
        };
        setLoading(true);
        (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .makeRequestOne */ .U)(requestOptions).then((res)=>{
            login(res?.data?.user, res?.data?.token);
        }).catch((error)=>{
            const errors = error?.response?.data;
            (0,_config_functions__WEBPACK_IMPORTED_MODULE_14__/* .displayErrors */ .hP)(form, errors);
            if (errors?.non_field_errors) {
                (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_15__.showNotification)({
                    title: "Error",
                    message: "Unable to login with the provided credentials",
                    color: "red",
                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconAlertTriangle, {
                        stroke: 1.5
                    })
                });
            } else {
                (0,_mantine_notifications__WEBPACK_IMPORTED_MODULE_15__.showNotification)({
                    title: "Error",
                    message: error?.message,
                    color: "red",
                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconAlertTriangle, {
                        stroke: 1.5
                    })
                });
            }
        }).finally(()=>{
            setLoading(false);
        });
    };
    const seoDetails = {
        url: "/auth/login",
        title: "Login",
        description: "Login to your account",
        keywords: "",
        image: "",
        twitter_card: ""
    };
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (query?.message) {
            (0,_providers_appProvider__WEBPACK_IMPORTED_MODULE_8__/* .globalLogout */ .J4)();
            const updatedQuery = {
                ...query
            };
            delete updatedQuery.message;
            replace({
                pathname: pathname,
                query: updatedQuery
            });
        } else {
            if (login_status) {
                push("/");
            }
        }
    }, [
        login_status
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_seo_SEOHeader__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                ...seoDetails
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Box, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Container, {
                    size: "xs",
                    py: 50,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Card, {
                        radius: "lg",
                        p: 50,
                        style: {
                            background: (0,_config_config__WEBPACK_IMPORTED_MODULE_12__/* .getTheme */ .gh)(theme) ? theme.colors.dark[4] : theme.colors.gray[0],
                            position: "relative"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.LoadingOverlay, {
                                visible: loading
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Center, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Image, {
                                            src: _config_constants__WEBPACK_IMPORTED_MODULE_13__/* .WEBSITE_LOGO */ .S0,
                                            radius: "md",
                                            className: classes.image,
                                            width: 200
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Title, {
                                        className: classes.title2,
                                        align: "center",
                                        children: "Login"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                        align: "center",
                                        children: "Please login to your account to get started."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                                        onSubmit: form.onSubmit((values)=>handleLogin()),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.TextInput, {
                                                        label: "Username",
                                                        placeholder: "Enter your username",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconUser, {
                                                            stroke: 1.5
                                                        }),
                                                        autoFocus: true,
                                                        ...form.getInputProps("username")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.PasswordInput, {
                                                        label: "Password",
                                                        placeholder: "Enter your password",
                                                        radius: "md",
                                                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconPassword, {
                                                            stroke: 1.5
                                                        }),
                                                        ...form.getInputProps("password")
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Grid.Col, {
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                                        align: "center",
                                                        spacing: 16,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cta_CallToActionButton__WEBPACK_IMPORTED_MODULE_5__/* .CallToActionButtonAction */ .LG, {
                                                                label: "Login",
                                                                type: "submit",
                                                                icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_tabler_icons__WEBPACK_IMPORTED_MODULE_6__.IconLogin, {
                                                                    stroke: 1.5,
                                                                    color: "white"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Group, {
                                                                spacing: 4,
                                                                p: 0,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                                        size: "sm",
                                                                        children: "Forgot Password?"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Anchor, {
                                                                        component: (next_link__WEBPACK_IMPORTED_MODULE_7___default()),
                                                                        href: "/auth/password/reset",
                                                                        size: "sm",
                                                                        children: "Reset Password"
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Group, {
                                                                spacing: 4,
                                                                p: 0,
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Text, {
                                                                        size: "sm",
                                                                        children: "Don't have an account?"
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mantine_core__WEBPACK_IMPORTED_MODULE_3__.Anchor, {
                                                                        component: (next_link__WEBPACK_IMPORTED_MODULE_7___default()),
                                                                        href: "/auth/signup",
                                                                        size: "sm",
                                                                        children: "Sign up"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
};
async function getServerSideProps(context) {
    const status = (0,cookies_next__WEBPACK_IMPORTED_MODULE_9__.getCookie)(_config_constants__WEBPACK_IMPORTED_MODULE_13__/* .LOCAL_STORAGE_KEYS.login_status */ .dA.login_status, context);
    return {
        props: {
            loginStatus: status ? status : false
        }
    };
}
Login.PageLayout = _layouts_HeaderAndFooterWrapper__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Login);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2247:
/***/ ((module) => {

module.exports = require("@mantine/core");

/***/ }),

/***/ 9445:
/***/ ((module) => {

module.exports = require("@mantine/form");

/***/ }),

/***/ 32:
/***/ ((module) => {

module.exports = require("@mantine/hooks");

/***/ }),

/***/ 914:
/***/ ((module) => {

module.exports = require("@mantine/notifications");

/***/ }),

/***/ 4116:
/***/ ((module) => {

module.exports = require("@tabler/icons");

/***/ }),

/***/ 8982:
/***/ ((module) => {

module.exports = require("cookies-next");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2905:
/***/ ((module) => {

module.exports = import("html-react-parser");;

/***/ }),

/***/ 5941:
/***/ ((module) => {

module.exports = import("swr");;

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [1664,213,1053,1463,8167,6004,9512], () => (__webpack_exec__(1881)));
module.exports = __webpack_exports__;

})();