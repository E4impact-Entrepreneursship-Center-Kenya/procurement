import React from 'react'
import HeaderAndFooterWrapper from '../../layouts/HeaderAndFooterWrapper'

const Account = () => {
  return (
    <div>Account</div>
  )
}

Account.PageLayout = HeaderAndFooterWrapper

export default Account